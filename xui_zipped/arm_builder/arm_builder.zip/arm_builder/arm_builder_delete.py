"""

Teardown Service Item Action for ARM Template Blueprint


"""

if __name__ == '__main__':
    import django

    django.setup()
from resourcehandlers.azure_arm.models import AzureARMHandler
from common.methods import set_progress
import sys
from utilities.logger import ThreadLogger

logger = ThreadLogger(__name__)


def get_provider_type_from_id(resource_id):
    return resource_id.split('/')[6]


def get_resource_type_from_id(resource_id):
    return resource_id.split('/')[7]


def get_api_version_key_from_id(id_value):
    provider_type = get_provider_type_from_id(id_value)
    resource_type = get_resource_type_from_id(id_value)
    ms_type = f'{provider_type}/{resource_type}'
    id_split = id_value.split('/')
    if len(id_split) == 11:
        ms_type = f'{ms_type}/{id_split[9]}'
    ms_type_us = ms_type.replace('.', '').replace('/', '_').lower()
    api_version_key = f'{ms_type_us}_api_version'
    return api_version_key


def get_api_version(resource_dict, id_value):
    if id_value.find('Microsoft.Resources/deployments') > -1:
        api_version = '2021-05-01'
    else:
        api_version_key = get_api_version_key_from_id(id_value)
        api_version = resource_dict[api_version_key]
    return api_version


def run(job, *args, **kwargs):
    resource = job.resource_set.first()
    if resource:
        set_progress(f"ARM Delete plugin running for resource: {resource}")
        try:
            azure_rh_id = resource.azure_rh_id
            if azure_rh_id is None:
                raise Exception(f'RH ID not found.')
        except:
            msg = "No RH ID set on the blueprint, continuing"
            set_progress(msg)
            return "SUCCESS", msg, ""
        try:
            azure_deployment_id = resource.azure_deployment_id
            if azure_rh_id is None:
                raise Exception(f'Deployment ID not found.')
        except:
            msg = "No Deployment ID set on the blueprint, continuing"
            set_progress(msg)
            return "SUCCESS", msg, ""

        # Instantiate Azure Resource Client
        rh: AzureARMHandler = AzureARMHandler.objects.get(id=azure_rh_id)
        wrapper = rh.get_api_wrapper()
        resource_client = wrapper.resource_client
        azure_resource_ids = []

        # Gather IDs to be deleted
        result_found = True
        resource_dict = resource.get_cf_values_as_dict()
        i = 0
        while result_found:
            field_name_id = f'output_resource_{i}_id'
            field_name_type = f'output_resource_{i}_type'
            try:
                resource_id = resource_dict[field_name_id]
                resource_type = resource_dict[field_name_type]
            except:
                result_found = False
                break
            if resource_type == 'virtualMachines':
                logger.info(f'Virtual Machine Resource found. ID: '
                            f'{resource_id}. This resource will not be deleted'
                            f'by this action. CloudBolt will deleted the '
                            f'server element (and dependencies) separately')
                i += 1
                continue
            if resource_id not in azure_resource_ids:
                azure_resource_ids.append(resource_id)
            i += 1

        # Capture Deployment ID to be deleted with teardown
        azure_resource_ids.append(azure_deployment_id)

        # Delete Resources
        for resource_id in azure_resource_ids:
            set_progress(f'Deleting resource_id: {resource_id}')
            api_version = get_api_version(resource_dict, resource_id)
            logger.debug(f'api_version: {api_version}')
            set_progress(f'Deleting Azure Resource with ID: {resource_id}')
            try:
                response = resource_client.resources.delete_by_id(resource_id,
                                                                  api_version)
                # Need to wait for each delete to complete in case there are
                # resources dependent on others (VM disks, etc.)
                wrapper._wait_on_operation(response)
            except:
                if resource_id.find('Microsoft.Network/networkInterfaces') > -1:
                    pass
                else:
                    error_string = (
                        f'Error: {sys.exc_info()[0]}. {sys.exc_info()[1]}, '
                        f'line: {sys.exc_info()[2].tb_lineno}')
                    set_progress(f'All resource_ids: {azure_resource_ids}')
                    set_progress(f'Delete Failed on resource_id: {resource_id}')
                    set_progress(error_string)
                    raise Exception(f'ARM Delete Failed. {error_string}')
        return "SUCCESS", "All resources successfully deleted", ""

    else:
        set_progress("Resource was not found")
        return "SUCCESS", "Resource was not found", ""


if __name__ == '__main__':
    run()
