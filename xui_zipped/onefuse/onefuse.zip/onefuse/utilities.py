from os import path
import json
from common.methods import set_progress
import re
from xui.onefuse.configuration.globals import VERIFY_CERTS
import sys
from infrastructure.models import CustomField
from django.db.models import Q

def get_cb_object_properties(resource,hook_point=None):
    # Generate a properties payload to be sent to OneFuse
    resource_values = vars(resource)
    properties_stack = {}

    # Add Resource variables to the properties stack
    for key in list(resource_values):
        if (
                key.find("_") != 0
        ):  # Ignoring hidden when building the payload to pass to OneFuse
            if (
                    key.split("_")[-1] == "id"
                    and key != "id"
                    and resource_values[key] != None
                    and resource_values[key] != ""
                    and key != "resource_handler_svr_id"
            ):
                fKeyName = key[0:-3]
                keyName = fKeyName
                keyValue = getattr(resource, fKeyName)
                if "password" in keyName.lower():
                    keyValue = "******"
            else:
                keyName = key
                keyValue = resource_values[key]
            properties_stack[keyName] = str(keyValue)

    # Add the Custom Field (parameter) values ot the properties stack
    cf_values = resource.get_cf_values_as_dict()
    cfvm = resource.get_cfv_manager()
    pwd_fields = []
    pwd_cfvs = cfvm.filter(~Q(pwd_value=None))
    for pwd_cfv in pwd_cfvs:
        pwd_fields.append(pwd_cfv.field.name)
    for key in cf_values.keys():
        keyName = key
        keyValue = cf_values[key]
        if keyName in pwd_fields:
            keyValue = "******"
        if type(keyValue) == str:
            if (
                (keyValue.find('{') == 0 or keyValue.find('[') == 0) 
                and keyValue.find('{{') != 0
            ):
                try: 
                    keyValue = json.loads(keyValue)
                except:
                    verbose_logging(f'JSON parse failed, sending string')
            properties_stack[keyName] = keyValue
        else: 
            properties_stack[keyName] = str(keyValue)

    # Add additional information useful for tracking in OneFuse
    try: 
        properties_stack["owner_email"] = resource.owner.user.email
    except:
        verbose_logging("Owner email could not be determined")
    try: 
        network_info = get_network_info(resource)
        for key in network_info.keys():
            properties_stack[key] = network_info[key]
    except:
        verbose_logging("WARN: Unable to determine Network Info for Server.")
    try: 
        hardware_info = get_hardware_info(resource)
    except:
        verbose_logging("WARN: Unable to determine Hardware Info for Server.")
    if hook_point != None:
        properties_stack["hook_point"] = hook_point
    return properties_stack

def get_network_info(resource):
    nics = resource.nics.all()
    network_info = {}
    for nic in nics:
        index_prop = f'OneFuse_VmNic{nic.index}'
        network_info[index_prop] = {}
        try:
            network_info[index_prop]["mac"] = nic.mac
        except Exception:
            pass
        try:
            network_info[index_prop]["ipAddress"] = nic.ip
        except Exception:
            pass
        try:
            network_info[index_prop]["nicLabel"] = nic.display
        except Exception:
            pass
        try:
            network_info[index_prop]["assignment"] = nic.bootproto
        except Exception:
            pass
        try: 
            network_info[index_prop]["label"] = nic.display
        except Exception:
            pass
        try:
            network_info[index_prop]["network"] = nic.network.name
        except Exception:
            pass
        try: 
            network_info[index_prop]["hostname"] = resource.hostname
        except Exception:
            pass
        try: 
            network_info[index_prop]["fqdn"] = (f'{resource.hostname}.'
                                             f'{resource.dns_domain}')
        except Exception:
            pass
        try: 
            network_info[index_prop]["gateway"] = nic.network.gateway
        except Exception:
            pass
        try: 
            network_info[index_prop]["dnsSuffix"] = resource.dns_domain
        except Exception:
            pass
        try: 
            network_info[index_prop]["dnsServers"] = []
            if nic.network.dns1:
                network_info[index_prop]["dnsServers"].append(nic.network.dns1)
            if nic.network.dns2:
                network_info[index_prop]["dnsServers"].append(nic.network.dns2)
        except Exception:
            pass
    return network_info

def get_hardware_info(resource):
    hardware_info = {}
    try: 
        hardware_info["dnsSuffix"] = resource.dns_domain
    except Exception:
        pass
    return hardware_info

def check_or_create_cf(cf_name,cf_type="STR"):
    #Check the existence of a custom field in CB. Create if it doesn't exist
    try: 
        cf = CustomField.objects.get(name=cf_name)
    except: 
        verbose_logging(f'Creating parameter: {cf_name}')
        cf = CustomField(
            name = cf_name,
            label = cf_name,
            type = cf_type,
            show_on_servers = True,
            description = "Created by the OneFuse plugin for CloudBolt"
        )
        cf.save()
        verbose_logging(f'Created parameter: {cf_name}')
    

def render(template,properties_stack,ofm):
    try:
        if template.find('{%') == -1 and template.find('{{') == -1:
            return template
        template = {
            "template": template,
            "templateProperties": properties_stack,
        }
        response = ofm.post("/templateTester/", json=template)
        response.raise_for_status()
        response_json = response.json()
        return response_json.get("value")
    except:
        error_string = (f'Error: {sys.exc_info()[0]}. {sys.exc_info()[1]}, '
                       f'line: {sys.exc_info()[2].tb_lineno}. Template: '
                       f'{template}')
        set_progress(error_string)
        raise Exception(f'OneFuse Template Render failed. {error_string}')

def get_connection_and_policy_values(prefix,properties_stack): 
    conn_and_policy_values = []
    pattern = re.compile(prefix)
    for key in properties_stack.keys():
        result = pattern.match(key)
        if result != None: 
            keyValue = properties_stack[key]
            if len(keyValue.split(":")) < 2:
                err = (f'OneFuse key was found but value is formatted wrong. '
                       f'Key: {key}, Value: {keyValue}')
                set_progress(err)
                raise Exception(err)
            endpoint = keyValue.split(":")[0]
            policy = keyValue.split(":")[1]
            try: 
                extras = keyValue.split(":")[2]
            except: 
                extras = ""
            try: 
                extras2 = keyValue.split(":")[3]
            except: 
                extras2 = ""
            conn_policy_value = {
                "endpoint": endpoint,
                "policy": policy,
                "extras": extras,
                "extras2": extras2
            }
            start = len(prefix)
            suffix = key[start:]
            if suffix:
                conn_policy_value["suffix"] = suffix
            conn_and_policy_values.append(conn_policy_value)
    return conn_and_policy_values

def get_matching_properties(prefix,properties_stack): 
    matching_properties = []
    pattern = re.compile(prefix)
    for key in properties_stack.keys():
        result = pattern.match(key)
        if result != None: 
            keyValue = properties_stack[key]
            matching_properties.append(keyValue)
    return matching_properties

def add_tracking_id_to_headers(headers,tracking_id):
    if tracking_id != None and tracking_id != "":
        headers["Tracking-Id"] = tracking_id
    return headers

def convert_object_to_string(value):
    if type(value) == 'list' or type(value) == 'dict':
        return json.dumps(value)
    return value

def request(ofm,path,template,tracking_id="",method='post'):
    #Addresses POST/PUT requests to OneFuse with async responses - should be 
    #any policy executions. Creating a new SPS for example doesn't use async
    def get_job_json(ofm,job_id):
        job_path = f'/jobMetadata/{job_id}/'
        job_response = ofm.get(job_path)
        job_json = job_response.json()
        return job_json
    #Submit request
    try: 
        if method == 'post': 
            response = ofm.post(path, json=template)
        elif method == 'put':
            response = ofm.put(path, json=template)
        else: 
            raise Exception(f'This action only supports post and put calls. '
                            f'Requested method: {method}')
        response.raise_for_status()
        response_json = response.json()
        response_status = response.status_code 
        verbose_logging(f'OneFuse Post Response status: {response_status}')
        #Async returns a 202
        if response_status == 202: 
            import time
            job_id = response_json["id"]
            sleep_seconds = 5
            total_seconds = 0
            max_sleep = get_max_sleep(path)
            job_json = get_job_json(ofm,job_id)
            job_state = job_json["jobState"]
            while job_state != 'Successful' and job_state != 'Failed':
                verbose_logging(f'Waiting for job completion. Sleeping for 5 '
                                f'seconds. Job state: {job_state}')
                time.sleep(sleep_seconds)
                total_seconds += sleep_seconds
                if total_seconds > max_sleep: 
                    raise Exception(f'Action timeout. OneFuse job exceeded '
                                    f'{max_sleep} seconds')
                job_json = get_job_json(ofm,job_id)
                job_state = job_json["jobState"]
            if job_state == 'Successful':
                verbose_logging('OneFuse Job Successful')
                mo_string = job_json["responseInfo"]["payload"]
                mo_json = json.loads(mo_string)
                mo_json["trackingId"] = job_json["jobTrackingId"]
            else: 
                error_msg = job_json["responseInfo"]["payload"]
                error_string = f'OneFuse job failure. {job_state}: {error_msg}'
                set_progress(f'OneFuse job failure. Error: {error_string}')
                raise Exception(error_string)
        #Non-Async (ex: SPS) Returns a 201
        else: 
            print('else')
            mo_json = response_json
            mo_json["trackingId"] = response.headers["Tracking-Id"]
    except:
        error_string = (f'Error: {sys.exc_info()[0]}. {sys.exc_info()[1]}, '
                       f'line: {sys.exc_info()[2].tb_lineno}')
        set_progress(error_string)
        raise Exception(f'OneFuse Async call failed. {error_string}')
    verbose_logging(f'mo_json: {mo_json}')
    return mo_json

def get_max_sleep(path):
    try:
        if path == '/customNames/':
            from xui.onefuse.configuration.globals import ONEFUSE_ASYNC_TIMEOUT_NAMING
            max_sleep = ONEFUSE_ASYNC_TIMEOUT_NAMING
        elif path == '/ipamReservations/':
            from xui.onefuse.configuration.globals import ONEFUSE_ASYNC_TIMEOUT_IPAM
            max_sleep = ONEFUSE_ASYNC_TIMEOUT_IPAM
        elif path == '/dnsReservations/':
            from xui.onefuse.configuration.globals import ONEFUSE_ASYNC_TIMEOUT_DNS
            max_sleep = ONEFUSE_ASYNC_TIMEOUT_DNS
        elif path == '/microsoftADComputerAccounts/':
            from xui.onefuse.configuration.globals import ONEFUSE_ASYNC_TIMEOUT_AD
            max_sleep = ONEFUSE_ASYNC_TIMEOUT_AD
        elif path == '/scriptingDeployments/':
            from xui.onefuse.configuration.globals import ONEFUSE_ASYNC_TIMEOUT_SCRIPTING
            max_sleep = ONEFUSE_ASYNC_TIMEOUT_SCRIPTING
        elif path == '/ansibleTowerDeployments/':
            from xui.onefuse.configuration.globals import ONEFUSE_ASYNC_TIMEOUT_ANSIBLETOWER
            max_sleep = ONEFUSE_ASYNC_TIMEOUT_ANSIBLETOWER
        else: 
            from xui.onefuse.configuration.globals import ONEFUSE_ASYNC_TIMEOUT_OTHER
            max_sleep = ONEFUSE_ASYNC_TIMEOUT_OTHER
    except:
        from xui.onefuse.configuration.globals import ONEFUSE_ASYNC_TIMEOUT_OTHER
        max_sleep = ONEFUSE_ASYNC_TIMEOUT_OTHER
    return max_sleep*60

def get_policy_by_name(ofm,policy_path,policy_name): 
    path = f'/{policy_path}/?filter=name.iexact:"{policy_name}"'
    policies_response = ofm.get(path)
    policies_response.raise_for_status()
    policies_json = policies_response.json()

    if policies_json["count"] > 1:
        raise Exception(f"More than one policy was returned matching "
                        f"the name: {policy_name}. Response: "
                        f"{json.dumps(policies_json)}")

    if policies_json["count"] == 0:
        raise Exception(f"No policies were returned matching the "
                        f"name: {policy_name}. Response: "
                        f"{json.dumps(policies_json)}")
    policy_json = policies_json["_embedded"][policy_path][0]
    return policy_json

def deprovision_mo(ofm,path): 
    tracking_id = get_tracking_id_from_mo(ofm,path)
    try: 
        verbose_logging(f'Deleting object from url: {path}, tracking_id: '
                        f'{tracking_id}')
        delete_response = ofm.delete(path)
        delete_response.raise_for_status()
        set_progress(f"Object deleted from the OneFuse database. "
                        f"Path: {path}")
    except:
        set_progress(f'Error: {sys.exc_info()[0]}. {sys.exc_info()[1]}, '
                     f'line: {sys.exc_info()[2].tb_lineno}')

def get_tracking_id_from_mo(ofm,path):
    try: 
        verbose_logging(f'Getting object from url: {path}')
        get_response = ofm.get(path)
        get_response.raise_for_status()
        get_json = get_response.json()
        full_job_path = get_json["_links"]["jobMetadata"]["href"]
        job_path = full_job_path.replace('/api/v3/onefuse','')
        job_response = ofm.get(job_path)
        job_response.raise_for_status()
        job_json = job_response.json()
        tracking_id = job_json["jobTrackingId"]
    except:
        set_progress(f'Error: {sys.exc_info()[0]}. {sys.exc_info()[1]}, '
                     f'line: {sys.exc_info()[2].tb_lineno}')
        set_progress('Tracking ID could not be determined for MO.')
        tracking_id = ""
    return tracking_id

def verbose_logging(msg):
    from xui.onefuse.configuration.globals import VERBOSE_LOGGING
    if VERBOSE_LOGGING: 
        set_progress(f'VERBOSE---> {msg}')

def sort_deprovision_props(props):
    sorted_props = []
    states = [
        "PostProvision",
        "PreApplication",
        "PreCreateResource",
        "HostnameOverwrite"        
    ]
    #loop through states in reverse order of provisioning
    for state in states:
        state_props = []
        for prop in props: 
            if prop["OneFuse_CBHookPointString"] == state:
                state_props.append(prop)
        #Sort state_props in reverse
        state_props.sort(key=lambda x: x["OneFuse_Suffix"], reverse=True)
        sorted_props = sorted_props + state_props
    return sorted_props

def delete_output_job_results(managed_object,run_type):
    #Scripting and Ansible Tower can have massive response payloads, this
    #Function cleans the output to keep the MO a manageable size
    if run_type == 'ansible_tower':
        verbose_logging(f'prov len: {len(managed_object["provisioningJobResults"])}')
        for i in range(len(managed_object["provisioningJobResults"])):
            managed_object["provisioningJobResults"][i]["output"] = ""
            verbose_logging(f'AT Output deleted for provisioning.')
        verbose_logging(f'de len: {len(managed_object["deprovisioningJobResults"])}')
        for i in range(len(managed_object["deprovisioningJobResults"])):
            managed_object["provisioningJobResults"][i]["output"] = ""
            verbose_logging(f'AT Output deleted for deprovisioning.')
    elif run_type == "scripting":
        max_char_limit = 5000
        if len(json.dumps(managed_object)) > max_char_limit:
            verbose_logging(f'Object exceeds {max_char_limit} chars. Removing job '
                            f'output.') 
            try:
                managed_object["provisioningDetails"]["output"] = []
                verbose_logging(f'Scripting Output deleted for provisioning.')
            except:
                verbose_logging(f'MO does not include provisioningDetails '
                                f'to be cleaned.') 
            try:
                managed_object["deprovisioningDetails"]["output"] = []
                verbose_logging(f'Scripting Output deleted for deprovisioning.')
            except:
                verbose_logging(f'MO does not include deprovisioningDetails '
                                f'to be cleaned.') 
    else:
        verbose_logging(f'Invalid run_type: {run_type}') 
    return managed_object
