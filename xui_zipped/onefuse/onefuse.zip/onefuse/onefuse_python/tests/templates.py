username = 'admin'
password = 'admin'
host = 'se-1f-demo-1-3.sovlabs.net'

template_properties = {
    "dnsPolicy": "prod",
    "customizationSpec": "Linux",
    "OneFuse_VRA8_Flavor": "medium",
    "OneFuse_SPS_OS": "sps_os_centos7",
    "OneFuse_AnsibleTowerPolicy_Trigger": "true",
    "nameLocation": "atl",
    "nameGroup": "tb",
    "nameOS": "l",
    "inputProperties": {
        "image": "CentOS7",
        "hostSelectionIds": [
            "3fccee63-c8b0-43b0-858e-cd1cdd1c5a8d"
        ],
        "componentId": "Cloud_Machine_1",
        "endpointId": "c31ed9de-577d-4890-a404-4510cb1014a6",
        "externalIds": [
            "57033c58-f4fa-49b1-80d8-4cec6a42cc82"
        ],
        "blueprintId": "1abc3eed-3775-444a-92d4-3b3b91882760",
        "tags": {},
        "resourceNames": [
            "Cloud_Machine_1-mcm1116-167232203088"
        ],
        "ebs.error.message": None,
        "componentTypeId": "Cloud.Machine",
        "requestId": "2000a54d-ec15-4eeb-847f-35402fd27336",
        "deploymentId": "83d56316-210c-4119-81af-fa1874a3104e",
        "zoneId": "d2e55550-3897-48ff-909b-1ddfeaed06d2",
        "projectId": "bf17a1d4-3129-4df3-ad3d-bedea3749ef6",
        "resourceIds": [
            "ee89963d-9a56-446a-96b3-a72650a90752"
        ]
    },
    "ipamApp": "web",
    "OneFuse_SPS_Group": "sps_group_testblueprints",
    "memoryGB": "1",
    "cpuCount": "1",
    "OneFuse_SPS_App": "sps_app_apache_ansible_tower",
    "image": "CentOS7",
    "ouGroup": "TestBlueprints",
    "Global_Props": {
        "memoryGB": "1",
        "cpuCount": "1"
    },
    "OneFuse_SPS_Location": "sps_location_atl",
    "OneFuse_NamingPolicy": "onefuse:{{resourceType}}",
    "adPolicy": "prod",
    "familyOS": "linux",
    "count": "1",
    "OneFuse_IpamPolicy_Nic0": "se_onefuse_dev_8067:solarwinds_{{ipamLocation}}{{ipamEnv}}",
    "flavor": "medium",
    "OneFuse_ResourceName": "Cloud_Machine_1-mcm1116-167232203088",
    "nameApp": "ap",
    "OneFuse_UpstreamProvider": "vRealize Automation 8",
    "OneFuse_DnsPolicy_Nic0": "onefuse:solarwinds_sovlabs_net:sovlabs.net",
    "folderName": "VRM-BACKUPEXCLUDED/demo/TestBlueprints/PROD",
    "OneFuse_CreateProperties_Env_1_Char": {
        "key": "MyProperty",
        "value": "{{environment[:1] | lower}}"
    },
    "OneFuse_ADPolicy": "onefuse:{{adPolicy}}",
    "deployNameEnv": "Prod",
    "OneFuse_ProjectName": "TestBlueprints",
    "nameEnv": "p",
    "OneFuse_SPS_Size": "sps_size_small",
    "OneFuse_EventTopicId": "compute.allocation.pre",
    "OneFuse_AnsibleTowerPolicy_ComputeProvisionPostLate_apache": "onefuse:linux_install_apache::",
    "OneFuse_SPS_GlobalProperties": "sps_globalproperties",
    "ipamEnv": "prod",
    "OneFuse_UpstreamProviderVersion": {
        "build": "7747939",
        "version": "1.3.0"
    },
    "s3NameEnv": "production",
    "OneFuse_DeploymentName": "b bv bv",
    "OneFuse_CreateProperties_Compliance": {
        "key": "{% if \"None\" != \"None\" %}OneFuse_SPS_Compliance{% endif %}",
        "value": "sps_compliance_None"
    },
    "OneFuse_RequestedBy": "mbombard",
    "resourceGroupName": "VRM-BACKUPEXCLUDED/demo/TestBlueprints/PROD",
    "ipamLocation": "atl",
    "deployNameApp": "APACHE",
    "OneFuse_ServiceNowCmdbPolicy": "se_onefuse_dev_8067:{{familyOS}}",
    "OneFuse_SPS_Env": "sps_env_prod",
    "folderEnv": "PROD",
    "ouEnv": "PRD",
    "dnsSuffix": "infoblox851.sovlabs.net",
    "folderGroup": "TestBlueprints",
    "location": "atl",
    "OneFuse_PropertyToolkit": "onefuse:true",
    "s3NameGroup": "testblueprints",
    "sgEnv": "prod",
    "resourceType": "machine",
    "OneFuse_VmNic0": {},
    "OneFuse_VmNic1": {},
    "OneFuse_VmNic2": {},
    "OneFuse_VmNic3": {},
    "OneFuse_VmNic4": {},
    "OneFuse_VmNic5": {},
    "OneFuse_VmNic6": {},
    "OneFuse_VmNic7": {},
    "OneFuse_VmNic8": {},
    "OneFuse_VmNic9": {},
    "OneFuse_VmHardware": {}
}
