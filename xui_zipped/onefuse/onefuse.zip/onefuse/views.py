from django.shortcuts import render

from extensions.views import admin_extension
from xui.onefuse.cb_onefuse_admin import CbOneFuseManager
from utilities.permissions import cbadmin_required
from utilities.decorators import dialog_view
from utilities.models import ConnectionInfo

@admin_extension(title="OneFuse Integration",
                 description="OneFuse integration library for CloudBolt "
                             "scripts and plugins.")
def onefuse_admin(request, **kwargs):
    context= {
        'docstring': CbOneFuseManager.__doc__,
        'a':'b'
    }
    return render(request, 'onefuse/templates/onefuse_admin.html',
                  context=context)