from django.shortcuts import render

from extensions.views import admin_extension
from xui.onefuse.api_wrapper import OneFuseConnector
from utilities.permissions import cbadmin_required
from utilities.decorators import dialog_view
from utilities.models import ConnectionInfo

@admin_extension(title="OneFuse Integration",
                 description="OneFuse integration library for CloudBolt "
                             "scripts and plugins.")
def onefuse_admin(request, **kwargs):
    context= {
        'docstring': OneFuseConnector.__doc__,
        'a':'b'
    }
    return render(request, 'onefuse/templates/onefuse_admin.html',
                  context=context)