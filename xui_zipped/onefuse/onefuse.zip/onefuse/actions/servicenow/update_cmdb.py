if __name__ == '__main__':
    import os
    import sys
    import django
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
    sys.path.append('/opt/cloudbolt')
    django.setup()

import json
from common.methods import set_progress
from jobs.models import Job
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, *args, **kwargs):
    for server in job.server_set.all():
        set_progress(f"This plug-in is running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        hook_point = kwargs.get("hook_point")
        properties_stack = utilities.get_cb_object_properties(server,hook_point)
        prefix = 'OneFuse_ServiceNowCmdb'
        matching_props = utilities.get_matching_property_names(prefix,
                                                           properties_stack)
        if len(matching_props) > 0: 
            main_policy = None
            cmdb_policies = []
            for matching_prop in matching_props: 
                print(matching_prop)
                suffix = matching_prop.replace(prefix,'')
                if suffix == '':
                    main_policy = matching_prop
                elif suffix.find("_") == 0:
                    #Remove the leading underscore from suffix
                    matching_prop["suffix"] = matching_prop["suffix"][1:]
                    cmdb_policies.append(matching_prop)
            cmdb_policies.sort()
            #Process the main_policy last
            cmdb_policies.insert(0,main_policy)
            
            for cmdb_policy in cmdb_policies:
                cfv = server.get_cfv_for_custom_field(cmdb_policy).str_value
                print(f'cfv: {cfv}, cmdb_policy: {cmdb_policy}')
                mo = json.loads(cfv)
                onefuse_endpoint = mo["endpoint"]
                mo_id = mo["id"]
                suffix = matching_prop.replace(prefix,'')
                if onefuse_endpoint and mo_id: 
                    utilities.verbose_logging(f"Starting OneFuse Delete CMDB "
                        f" Object. Endpoint: {onefuse_endpoint}, CMDB ID: "
                        f"{mo_id}")
                    #Delete Name Object
                    ofm = OneFuseManager(onefuse_endpoint)
                    try: 
                        tracking_id = server.OneFuse_Tracking_Id
                    except: 
                        tracking_id = ""
                    response_json = ofm.update_cmdb(properties_stack,mo_id,
                                                    tracking_id)
                    response_json["endpoint"] = onefuse_endpoint
                    cf_name = f'OneFuse_ServiceNowCmdb'
                    try:
                        cf_name += f'_{cmdb_policy["suffix"]}'
                    except:
                        pass
                    utilities.check_or_create_cf(cf_name)
                    #Deleting the execution details from the CF. Execution makes the
                    #MO too large for the CB DB
                    del response_json["executionDetails"]
                    response_json["OneFuse_Suffix"] = suffix
                    server.set_value_for_custom_field(cf_name,
                                                json.dumps(response_json))
                    server.OneFuse_Tracking_Id = response_json["trackingId"]
                    server.save()
                    return_str = f"CMDB Record was successfully Updated. "
                    return "SUCCESS",return_str, ""
                else: 
                    set_progress(f"OneFuse ServiceNow CMDB endpoint or ID was "
                                f"missing, Execution skipped")
                    return "SUCCESS", (f"No OneFuse ServiceNow CMDB object "
                                    f"identified. AD deletion skipped."), ""
        else: 
            msg = (f"Existing OneFuse CMDB policy, not found. "
                         f"Execution skipped")
            set_progress(msg)
            return "SUCCESS", (msg), ""

if __name__ == '__main__':
    job_id = sys.argv[1]
    job = Job.objects.get(id=job_id)
    run = run(job)
    if run[0] == 'FAILURE':
        set_progress(run[1])
