import json
from common.methods import set_progress
from jobs.models import Job
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, *args, **kwargs):
    for server in job.server_set.all():
        set_progress(f"This plug-in is running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        hook_point = kwargs.get("hook_point")
        properties_stack = utilities.get_cb_object_properties(server,hook_point)
        endpoint_policies = utilities.get_connection_and_policy_values(
                            'OneFuse_ServiceNowCmdb',properties_stack)
        if len(endpoint_policies) > 0: 
            main_policy = None
            cmdb_policies = []
            for endpoint_policy in endpoint_policies: 
                try:
                    suffix = endpoint_policy["suffix"]
                    is_main_policy = False
                except:
                    main_policy = endpoint_policy
                    is_main_policy = True
                if is_main_policy == False:
                    if suffix.find("_") == 0:
                        #Remove the leading underscore from suffix
                        endpoint_policy["suffix"] = endpoint_policy["suffix"][1:]
                    cmdb_policies.append(endpoint_policy)
            #De-Provision CMDB policies in reverse order
            cmdb_policies.sort(reverse=True)
            #Process the main_policy last
            cmdb_policies.append(main_policy)

            for endpoint_policy in cmdb_policies:

            mo = json.loads(object_json)
            onefuse_endpoint = mo["endpoint"]
            mo_name = mo["name"]
            mo_id = mo["id"]
            if onefuse_endpoint and mo_id: 
                utilities.verbose_logging(f"Starting OneFuse Delete AD Object."
                                          f" Policy: {mo_name}, Endpoint: "
                                          f"{onefuse_endpoint}, AD ID: {mo_id}")
                #Delete Name Object
                ofm = OneFuseManager(onefuse_endpoint)
                deleted_obj_name = ofm.deprovision_ad(mo_id)
                return_str = f"AD Computer was successfully deleted from the "\
                             f"OneFuse database. Name: {deleted_obj_name}"
                return "SUCCESS",return_str, ""
            else: 
                set_progress(f"OneFuse AD endpoint or ID was missing, "
                             f"Execution skipped")
                return "SUCCESS", (f"No OneFuse AD object identified. AD "
                                   f"deletion skipped."), ""
        else: 
            set_progress(f"OneFuse AD policy, endpoint or AD was "
                         f"missing, Execution skipped")
            return "SUCCESS", (f"No OneFuse AD ID identified. AD deletion"
                               f" skipped."), ""

