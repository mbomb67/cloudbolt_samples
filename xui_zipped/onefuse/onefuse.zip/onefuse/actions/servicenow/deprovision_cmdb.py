if __name__ == '__main__':
    import os
    import sys
    import django
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
    sys.path.append('/opt/cloudbolt')
    django.setup()


import json
from common.methods import set_progress
from jobs.models import Job
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, *args, **kwargs):
    for server in job.server_set.all():
        set_progress(f"This plug-in is running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        hook_point = kwargs.get("hook_point")
        properties_stack = utilities.get_cb_object_properties(server,hook_point)
        prefix = 'OneFuse_ServiceNowCmdb'
        matching_props = utilities.get_matching_property_names(prefix,
                                                           properties_stack)
        if len(matching_props) > 0: 
            main_policy = None
            cmdb_policies = []
            for matching_prop in matching_props: 
                print(f'matching_prop: {matching_prop}')
                suffix = matching_prop.replace(prefix,'')
                if suffix == '':
                    main_policy = matching_prop
                elif suffix.find("_") == 0:
                    #Remove the leading underscore from suffix
                    matching_prop["suffix"] = matching_prop["suffix"][1:]
                    cmdb_policies.append(matching_prop)
            #De-Provision CMDB policies in reverse order
            cmdb_policies.sort(reverse=True)
            #Process the main_policy last
            if main_policy:
                cmdb_policies.append(main_policy)

            if len(cmdb_policies) > 0:
                for cmdb_policy in cmdb_policies:
                    print(f'cmdb_policy: {cmdb_policy}')
                    cfv = server.get_cfv_for_custom_field(cmdb_policy).str_value
                    print(f'cfv: {cfv}, cmdb_policy: {cmdb_policy}')
                    mo = json.loads(cfv)
                    onefuse_endpoint = mo["endpoint"]
                    mo_id = mo["id"]
                    if onefuse_endpoint and mo_id: 
                        utilities.verbose_logging(f"Starting OneFuse Delete CMDB "
                            f" Object. Endpoint: {onefuse_endpoint}, CMDB ID: "
                            f"{mo_id}")
                        #Delete Name Object
                        ofm = OneFuseManager(onefuse_endpoint)
                        deleted_obj_name = ofm.deprovision_cmdb(mo_id)
                        return_str = f"CMDB Record was successfully deleted from the "\
                                    f"OneFuse database. Name: {deleted_obj_name}"
                        return "SUCCESS",return_str, ""
                    else: 
                        msg = (f"OneFuse ServiceNow CMDB endpoint or ID was "
                                    f"missing, Execution skipped")
                        set_progress(msg)
                        return "SUCCESS", msg, ""
            else: 
                msg = f"No matching OneFuse CMDB properties found, Execution skipped"
                set_progress(msg)
                return "SUCCESS", msg, ""
        else: 
            msg = f"No matching OneFuse CMDB properties found, Execution skipped"
            set_progress(msg)
            return "SUCCESS", msg, ""

if __name__ == '__main__':
    job_id = sys.argv[1]
    job = Job.objects.get(id=job_id)
    run = run(job)
    if run[0] == 'FAILURE':
        set_progress(run[1])