if __name__ == '__main__':
    import os
    import sys
    import django

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
    sys.path.append('/opt/cloudbolt')
    django.setup()

import json
from jobs.models import Job
from common.methods import set_progress
from xui.onefuse.cb_onefuse_admin import CbOneFuseManager, Utilities
from utilities.logger import ThreadLogger

logger = ThreadLogger(__name__)


def run(job, **kwargs):
    server = job.server_set.first()
    if server:
        utilities = Utilities(logger)
        set_progress(f"cb_onefuse_naming running for server {server}")
        logger.debug(f"Dictionary of keyword args passed to this plug-in: "
                     f"{kwargs.items()}")
        hook_point = 'generated_hostname_overwrite'

        properties_stack = utilities.get_cb_object_properties(server,
                                                              hook_point)
        logger.debug(f'properties_stack: {properties_stack}')
        endpoint_policies = utilities.get_connection_and_policy_values(
            'OneFuse_NamingPolicy', properties_stack)
        logger.debug(f'endpoint_policies: {endpoint_policies}')
        if len(endpoint_policies) == 1:
            endpoint_policy = endpoint_policies[0]
            onefuse_endpoint = endpoint_policy["endpoint"]
            policy_name = endpoint_policy["policy"]
            set_progress(f"Starting OneFuse Naming Policy: "
                         f"{policy_name}, Endpoint: "
                         f"{onefuse_endpoint}")
            try:
                tracking_id = server.OneFuse_Tracking_Id
            except:
                tracking_id = ""
            ofm = CbOneFuseManager(onefuse_endpoint, logger=logger)
            name_json = ofm.provision_naming(policy_name, properties_stack,
                                                 tracking_id)
            logger.debug(f'name_json: {name_json}')
            machine_name = name_json.get("name")
            server.hostname = machine_name
            name_json["endpoint"] = onefuse_endpoint
            utilities.check_or_create_cf("OneFuse_Naming")
            server.OneFuse_Naming = json.dumps(name_json)
            server.OneFuse_Tracking_Id = name_json.get("trackingId")
            server.save()
            set_progress(f"hostname being set to: {server.hostname}")
            return "SUCCESS", machine_name, ""
        elif len(endpoint_policies) > 1:
            set_progress(f'More than one OneFuse_NamingPolicy was returned. '
                         f'endpoint_policies: {endpoint_policies}')
            return "FAILURE", "", f"More than one naming policy was found."
        else:
            set_progress("OneFuse_NamingPolicy parameter is not set on "
                         "the server, OneFuse naming will not be "
                         "executed. Keeping existing hostname")
    else:
        set_progress("Server was not found")
        return "FAILURE", "", f"Server was not found."


if __name__ == '__main__':
    job_id = sys.argv[1]
    job = Job.objects.get(id=job_id)
    run = run(job)
    if run[0] == 'FAILURE':
        set_progress(run[1])
