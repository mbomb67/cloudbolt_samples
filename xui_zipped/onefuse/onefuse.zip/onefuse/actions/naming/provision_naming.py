import json
from common.methods import set_progress
from jobs.models import Job
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, **kwargs):
    server = job.server_set.first()
    if server:
        set_progress(f"cb_onefuse_naming running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        hook_point = 'generated_hostname_overwrite'
        properties_stack = utilities.get_cb_object_properties(server,hook_point)
        endpoint_policies = utilities.get_connection_and_policy_values(
                            'OneFuse_NamingPolicy',properties_stack)
        utilities.verbose_logging(f'endpoint_policies: {endpoint_policies}')
        if len(endpoint_policies) == 1:
            endpoint_policy = endpoint_policies[0]
            onefuse_endpoint = endpoint_policy["endpoint"]
            policy_name = endpoint_policy["policy"]
            set_progress(f"Starting OneFuse Naming Policy: "
                         f"{policy_name}, Endpoint: "
                         f"{onefuse_endpoint}")
            try: 
                tracking_id = server.OneFuse_Tracking_Id
            except: 
                tracking_id = ""
            ofm = OneFuseManager(onefuse_endpoint)
            name_json = ofm.provision_naming(policy_name, properties_stack, 
                                             tracking_id)
            utilities.verbose_logging(f'name_json: {name_json}')
            machine_name = name_json.get("name")
            server.hostname = machine_name
            name_json["endpoint"] = onefuse_endpoint
            utilities.check_or_create_cf("OneFuse_Naming")
            server.OneFuse_Naming = json.dumps(name_json)
            server.OneFuse_Tracking_Id = name_json.get("trackingId")
            server.save()
            set_progress(f"hostname being set to: {server.hostname}")
            return "SUCCESS", machine_name, ""
        elif len(endpoint_policies) > 1:
            set_progress(f'More than one OneFuse_NamingPolicy was returned. '
                         f'endpoint_policies: {endpoint_policies}')
            return "FAILURE", "", f"More than one naming policy was found."
        else:
            set_progress("OneFuse_NamingPolicy parameter is not set on "
                         "the server, OneFuse naming will not be "
                         "executed. Keeping existing hostname")
    else:
        set_progress("Server was not found")
        return "FAILURE", "", f"Server was not found."

