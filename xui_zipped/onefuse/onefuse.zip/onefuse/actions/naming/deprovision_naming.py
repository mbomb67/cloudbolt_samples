import json
from common.methods import set_progress
from jobs.models import Job
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, *args, **kwargs):
    for server in job.server_set.all():
        set_progress(f"This plug-in is running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        naming_json = server.get_cfv_for_custom_field("OneFuse_Naming")
        utilities.verbose_logging(f'naming_json: {naming_json}')
        if naming_json: 
            naming_json = naming_json.value_as_string
            mo = json.loads(naming_json)
            onefuse_endpoint = mo["endpoint"]
            mo_name = mo["name"]
            mo_id = mo["id"]
            if onefuse_endpoint and mo_id: 
                utilities.verbose_logging(f"Starting OneFuse Delete Name "
                            f"Object. Policy: {mo_name}, Endpoint: "
                            f"{onefuse_endpoint}, Name ID: {mo_id}")
                #Delete Name Object
                ofm = OneFuseManager(onefuse_endpoint)
                deleted_name = ofm.deprovision_naming(mo_id)
                return_str = f"Name was successfully deleted from the "\
                             f"OneFuse database. Path: {deleted_name}"
                return "SUCCESS",return_str, ""
            else: 
                set_progress(f"OneFuse Naming policy, endpoint of Name ID was"
                             f" missing, Execution skipped")
                return "SUCCESS", (f"No OneFuse Name ID identified. Name "
                                   f"deletion skipped."), ""
        else: 
            set_progress(f"OneFuse Naming policy, endpoint of Name ID was "
                         f"missing, Execution skipped")
            return "SUCCESS", (f"No OneFuse Name ID identified. Name deletion"
                               f" skipped."), ""

