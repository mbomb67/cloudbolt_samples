if __name__ == '__main__':
    import os
    import sys
    import django

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
    sys.path.append('/opt/cloudbolt')
    django.setup()

import json
from common.methods import set_progress
from jobs.models import Job
from xui.onefuse.cb_onefuse_admin import CbOneFuseManager, Utilities
from utilities.logger import ThreadLogger

logger = ThreadLogger(__name__)


def run(job, **kwargs):
    for server in job.server_set.all():
        set_progress(f"This plug-in is running for server {server}")
        logger.debug(f"Dictionary of keyword args passed to this "
                     f"plug-in: {kwargs.items()}")
        naming_json = server.get_cfv_for_custom_field("OneFuse_Naming")
        logger.debug(f'naming_json: {naming_json}')
        if naming_json:
            naming_json = naming_json.value_as_string
            mo = json.loads(naming_json)
            onefuse_endpoint = mo["endpoint"]
            mo_name = mo["name"]
            mo_id = mo["id"]
            if onefuse_endpoint and mo_id:
                set_progress(f"Starting OneFuse Delete Name "
                             f"Object. Policy: {mo_name}, Endpoint: "
                             f"{onefuse_endpoint}, Name ID: {mo_id}")
                # Delete Name Object
                ofm = CbOneFuseManager(onefuse_endpoint, logger=logger)
                deleted_name = ofm.deprovision_naming(mo_id)
                return_str = f"Name was successfully deleted from the " \
                             f"OneFuse database. Path: {deleted_name}"
                return "SUCCESS", return_str, ""
            else:
                set_progress(f"OneFuse Naming policy, endpoint of Name ID was"
                             f" missing, Execution skipped")
                return "SUCCESS", (f"No OneFuse Name ID identified. Name "
                                   f"deletion skipped."), ""
        else:
            message = f"No OneFuse Name ID identified. Name deletion skipped."
            set_progress(message)
            return "SUCCESS", message, ""


if __name__ == '__main__':
    job_id = sys.argv[1]
    job = Job.objects.get(id=job_id)
    run = run(job)
    if run[0] == 'FAILURE':
        set_progress(run[1])
