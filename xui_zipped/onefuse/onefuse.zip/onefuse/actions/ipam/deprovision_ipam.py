from common.methods import set_progress
from jobs.models import Job
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, **kwargs):
    server = job.server_set.first()
    if server:
        set_progress(f"deprovision_ipam running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        properties_stack = utilities.get_cb_object_properties(server)
        ipam_props = utilities.get_matching_properties('OneFuse_Ipam_Nic',
                                                        properties_stack)
        set_progress(f'ipam_props: {ipam_props}')
        if len(ipam_props) > 0:
            for ipam_prop in ipam_props:
                #ipam_json = ipam_prop
                ipam_id = ipam_prop.get("id")
                ipam_hostname = ipam_prop.get("hostname")
                onefuse_endpoint = ipam_prop.get("endpoint")
                utilities.verbose_logging(f'Preparing to deprovision IPAM for '
                                          f'hostname: {ipam_hostname}')
                ofm = OneFuseManager(onefuse_endpoint)
                ofm.deprovision_ipam(ipam_id)
                set_progress("IPAM deletion completed.")
            return "SUCCESS", "", ""
        else:
            set_progress("No OneFuse_Ipam_NicN properties found on "
                         "the server, Deprovision IPAM will not be executed.")
    else:
        set_progress("Server was not found")
        return "FAILED", "", "Server was not found"
