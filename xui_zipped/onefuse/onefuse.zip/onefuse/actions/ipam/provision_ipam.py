import json
from common.methods import set_progress
from jobs.models import Job
from resourcehandlers.models import ResourceNetwork
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, **kwargs):
    server = job.server_set.first()
    if server:
        set_progress(f"provision_ipam running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this"
                                   f" plug-in: {kwargs.items()}")
        hook_point = kwargs.get("hook_point")
        properties_stack = utilities.get_cb_object_properties(server,hook_point)
        endpoint_policies = utilities.get_connection_and_policy_values(
                            'OneFuse_IpamPolicy_Nic',properties_stack)
        utilities.verbose_logging(f'endpoint_policies: {endpoint_policies}')
        if endpoint_policies:
            for endpoint_policy in endpoint_policies:
                onefuse_endpoint = endpoint_policy["endpoint"]
                policy_name = endpoint_policy["policy"]
                nic_suffix = int(endpoint_policy["suffix"])
                set_progress(f"Starting OneFuse IPAM Policy: "
                            f"{policy_name}, Endpoint: {onefuse_endpoint}")
                try: 
                    tracking_id = server.OneFuse_Tracking_Id
                except: 
                    tracking_id = ""
                ofm = OneFuseManager(onefuse_endpoint)
                ipam_json = ofm.provision_ipam(policy_name,properties_stack,
                                               tracking_id)
                ipam_json["endpoint"] = onefuse_endpoint
                ip_address = ipam_json.get("ipAddress")
                nic_property = f'OneFuse_Ipam_Nic{nic_suffix}'
                utilities.check_or_create_cf(nic_property)
                server.set_value_for_custom_field(nic_property,
                                                json.dumps(ipam_json))
                ip_network = ipam_json.get("network")
                dns_domain = ipam_json.get("dnsSuffix")
                if ipam_json.get("primaryDns"): 
                    domain_name_server = ipam_json.get("primaryDns")
                if ipam_json.get("secondaryDns"): 
                    if domain_name_server: 
                        domain_name_server += ','
                    domain_name_server += ipam_json.get("secondaryDns")
                # It seems that the only way to drive the network is to set it
                # here (before vm provision)and then update the NICs later
                server.set_value_for_custom_field(f'sc_nic_{nic_suffix}',
                                                  ip_network)
                server.set_value_for_custom_field(f'sc_nic_{nic_suffix}_ip',
                                                  ip_address)
                server.set_value_for_custom_field(f'dns_domain',
                                                  dns_domain)
                server.set_value_for_custom_field(f'domain_name_server',
                                                  domain_name_server)
                utilities.verbose_logging(f'all nics: {server.nics.all()}')
                # Not able to set NICs at this stage, being set during 
                # Pre-Network Configuration
                server.OneFuse_Tracking_Id = ipam_json["trackingId"]
                server.save()
                set_progress(f"IP being set to: {ip_address}")
            return "SUCCESS", "", ""
        else:
            set_progress("OneFuse_IpamPolicy_NicN parameter is not set on "
                         "the server, OneFuse IPAM will not be executed.")
    else:
        set_progress("Server was not found")
        return "FAILURE", "", "Server was not found"

