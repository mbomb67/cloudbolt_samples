import json
from common.methods import set_progress
from jobs.models import Job
from xui.onefuse import utilities
from resourcehandlers.models import ResourceNetwork

def run(job, **kwargs):
    server = job.server_set.first()
    if server:
        set_progress(f"provision_ipam running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        properties_stack = utilities.get_cb_object_properties(server)
        endpoint_policies = utilities.get_connection_and_policy_values(
                            'OneFuse_IpamPolicy_Nic',properties_stack)
        utilities.verbose_logging(f'endpoint_policies: {endpoint_policies}')
        if endpoint_policies:
            for endpoint_policy in endpoint_policies:
                nic_suffix = int(endpoint_policy["suffix"])
                nic_property = f'OneFuse_Ipam_Nic{nic_suffix}'
                set_progress(f"Starting OneFuse IPAM Policy preconfig for: "
                            f"OneFuse_Ipam_Nic{nic_suffix}")
                ipam_json = json.loads(
                    server.get_cfv_for_custom_field(nic_property).value_as_string
                )
                ip_network = ipam_json.get("network")
                network_results = ResourceNetwork.objects.filter(name=ip_network)
                if len(network_results) == 1:
                    resource_network = network_results[0]
                else: 
                    raise Exception(f'IPAM Preconfig failed. Unable to find '
                                f' network matching name: {ip_network}')
                nics = server.nics.filter(index=nic_suffix)
                if len(nics) == 1:
                    nic = nics.first()
                else: 
                    raise Exception(f'IPAM Preconfig failed. Incorrect number '
                                    f'of NICs found for NIC {nic_suffix}. '
                                    f'{len(nics)} NICs found.')
                #nic.ip = ipam_json.get("ipAddress")
                nic.gateway = ipam_json.get("gateway")
                #nic.dns_domain = ipam_json.get("dnsSuffix")
                #nic.dns1 = ipam_json.get("primaryDns")
                #nic.dns2 = ipam_json.get("secondaryDns")
                nic.netmask = ipam_json.get("netmask")
                #nic.network = resource_network
                nic.save()
                #set_progress(f'Setting addr: {nic.ip}, gw: {nic.gateway}, '
                            #f'domain: {nic.dns_domain}, dns1: {nic.dns1}, dns2'
                            #f': {nic.dns2}, network: {nic.network.name}, ' 
                            #f'netmask: {nic.netmask}')
            return "SUCCESS", "", ""
        else:
            set_progress("OneFuse_IpamPolicy_NicN parameter is not set on "
                         "the server, OneFuse IPAM will not be executed.")
    else:
        set_progress("Server was not found")
        return "FAILURE", "", "Server was not found"

