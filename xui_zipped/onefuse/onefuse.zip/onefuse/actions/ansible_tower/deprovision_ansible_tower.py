if __name__ == '__main__':
    import os
    import sys
    import django

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
    sys.path.append('/opt/cloudbolt')
    django.setup()

from common.methods import set_progress
from xui.onefuse.cb_onefuse_admin import CbOneFuseManager, Utilities
from utilities.logger import ThreadLogger
from jobs.models import Job

logger = ThreadLogger(__name__)


def run(job, **kwargs):
    server = job.server_set.first()
    if server:
        utilities = Utilities(logger)
        set_progress(f"deprovision_ansible_tower running for server {server}")
        logger.debug(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        properties_stack = utilities.get_cb_object_properties(server)
        matching_props = utilities.get_matching_properties(
            'OneFuse_AnsibleTower_', properties_stack)
        if len(matching_props) > 0:
            matching_props = utilities.sort_deprovision_props(matching_props)
            logger.debug(f'matching_props: {matching_props}')
            hostname = server.hostname
            for matching_prop in matching_props:
                id = matching_prop.get("id")
                onefuse_endpoint = matching_prop.get("endpoint")
                logger.debug(f'Preparing to deprovision Ansible '
                                          f'Tower for hostname: {hostname}, suffix: '
                                          f'{matching_prop["OneFuse_Suffix"]}, Hook string: '
                                          f'{matching_prop["OneFuse_CBHookPointString"]}')
                ofm = CbOneFuseManager(onefuse_endpoint, logger=logger)
                ofm.deprovision_ansible_tower(id)
                set_progress("Ansible Tower deletion completed.")
            return "SUCCESS", "", ""
        else:
            set_progress(
                "No OneFuse_AnsibleTower_ properties found on the server"
                ", Deprovision Ansible Tower will not be executed.")
    else:
        set_progress("Server was not found")
        return "FAILURE", "", "Server was not found"


if __name__ == '__main__':
    job_id = sys.argv[1]
    job = Job.objects.get(id=job_id)
    run = run(job)
    if run[0] == 'FAILURE':
        set_progress(run[1])
