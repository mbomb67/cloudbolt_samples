if __name__ == "__main__":
    import os
    import sys
    import django

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
    sys.path.append("/opt/cloudbolt")
    sys.path.append("/var/opt/cloudbolt/proserv")
    django.setup()

from common.methods import set_progress
from jobs.models import Job
from utilities.logger import ThreadLogger
from xui.onefuse.cb_onefuse_admin import CbOneFuseManager, Utilities

logger = ThreadLogger(__name__)


def run(job, **kwargs):
    server = job.server_set.first()
    if server:
        utilities = Utilities(logger)
        set_progress(f"deprovision_dns running for server {server}")
        logger.debug(f"Dictionary of keyword args passed to this "
                     f"plug-in: {kwargs.items()}")
        properties_stack = utilities.get_cb_object_properties(server)
        dns_props = utilities.get_matching_properties('OneFuse_Dns_Nic',
                                                      properties_stack)
        logger.debug(f'dns_props: {dns_props}')
        if len(dns_props) > 0:
            for dns_prop in dns_props:
                dns_id = dns_prop.get("id")
                dns_name = dns_prop.get("name")
                onefuse_endpoint = dns_prop.get("endpoint")
                set_progress(f'Preparing to deprovision DNS for '
                             f'hostname: {dns_name}')
                ofm = CbOneFuseManager(onefuse_endpoint, logger=logger)
                ofm.deprovision_dns(dns_id)
                set_progress("DNS deletion completed.")
            return "SUCCESS", "", ""
        else:
            set_progress("No OneFuse_Dns_NicN properties found on "
                         "the server, Deprovision DNS will not be executed.")
    else:
        set_progress("Server was not found")
        return "FAILURE", "", "Server was not found"


if __name__ == "__main__":
    job_id = sys.argv[1]
    j = Job.objects.get(id=job_id)
    run = run(j)
    if run[0] == "FAILURE":
        set_progress(run[1])
