from os import path

if __name__ == "__main__":
    import os
    import sys
    import django

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
    sys.path.append("/opt/cloudbolt")
    sys.path.append("/var/opt/cloudbolt/proserv")
    django.setup()

import json
from common.methods import set_progress
from jobs.models import Job
from resourcehandlers.models import ResourceNetwork
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, **kwargs):
    server = job.server_set.first()
    if server:
        set_progress(f"provision_dns running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        hook_point = kwargs.get("hook_point")
        properties_stack = utilities.get_cb_object_properties(server,hook_point)
        endpoint_policies = utilities.get_connection_and_policy_values(
                            'OneFuse_DnsPolicy_Nic',properties_stack)
        utilities.verbose_logging(f'endpoint_policies: {endpoint_policies}')
        if endpoint_policies:
            for endpoint_policy in endpoint_policies:
                onefuse_endpoint = endpoint_policy["endpoint"]
                policy_name = endpoint_policy["policy"]
                zones = []
                for zone in endpoint_policy["extras"].split(","):
                    zones.append(zone.strip())
                nic_suffix = int(endpoint_policy["suffix"])
                nic_ip_prop = f'sc_nic_{nic_suffix}_ip'
                try: 
                    ip_address = server.get_cfvs_for_custom_field(nic_ip_prop).first().value
                except: 
                    err_msg = (f"An IP address could not be determined for NIC "
                              f"{nic_suffix}. To use the OneFuse DNS module, "
                              f"you must use the {nic_ip_prop} property.")
                    Exception(err_msg)
                set_progress(f"Starting OneFuse DNS Policy: "
                            f"{policy_name}, Endpoint: {onefuse_endpoint}, "
                            f"IP: {ip_address}, Zones: {zones}, NIC suffix: "
                            f"{nic_suffix}")
                try: 
                    tracking_id = server.OneFuse_Tracking_Id
                except: 
                    tracking_id = ""
                ofm = OneFuseManager(onefuse_endpoint)
                dns_json = ofm.provision_dns(policy_name,properties_stack,
                                             ip_address,zones,tracking_id)
                dns_json["endpoint"] = onefuse_endpoint
                nic_property = f'OneFuse_Dns_Nic{nic_suffix}'
                utilities.check_or_create_cf(nic_property)
                server.set_value_for_custom_field(nic_property,
                                                json.dumps(dns_json))
                server.OneFuse_Tracking_Id = dns_json["trackingId"]
                server.save()
                set_progress(f"DNS record creation complete.")
            return "SUCCESS", "", ""
        else:
            set_progress("OneFuse_DnsPolicy_NicN parameter is not set on "
                         "the server, OneFuse DNS will not be executed.")
    else:
        set_progress("Server was not found")
        return "FAILED", "", "Server was not found"


if __name__ == "__main__":
    job_id = sys.argv[1]
    j = Job.objects.get(id=job_id)
    run = run(j)
    if run[0] == "FAILURE":
        set_progress(run[1])
