from common.methods import set_progress
from xui.onefuse.configuration.globals import MAX_RUNS
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, **kwargs):
    server = job.server_set.first()
    if server:
        set_progress(f"Property Toolkit running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        hook_point = kwargs.get("hook_point")
        if hook_point == None:
            #hostname overwrite isn't passing the hook_point in to the job
            hook_point = 'generated_hostname_overwrite'
        properties_stack = utilities.get_cb_object_properties(server,hook_point)
        endpoint_policies = utilities.get_connection_and_policy_values(
                            'OneFuse_PropertyToolkit',properties_stack)
        if endpoint_policies:
            if len(endpoint_policies) == 1:
                totalRuns = 0
                endpoint_policy = endpoint_policies[0]
                onefuse_endpoint = endpoint_policy["endpoint"]
                ofm = OneFuseManager(onefuse_endpoint)
                ptk_enabled = endpoint_policy["policy"]
                if ptk_enabled.lower() != "true": 
                        set_progress(f'OneFuse_PropertyToolkit value was not'
                                f' set to true. Exiting. Value: {ptk_enabled}')
                        return "SUCCESS", "", ""
                if hook_point == 'generated_hostname_overwrite':
                    calculated_max_runs = MAX_RUNS
                else:
                    calculated_max_runs = 1
                utilities.verbose_logging(f'PTK running at {hook_point} max '
                                f'runs set to: {calculated_max_runs}')
                while totalRuns < calculated_max_runs:
                    set_progress(f'Starting PTK run #: {totalRuns+1}')
                    #OneFuse_SPS groups
                    sps_properties = ofm.get_sps_properties(server)
                    properties_stack = ofm.render_and_apply_properties(
                                        sps_properties,server,properties_stack)

                    #OneFuse_CreateProperties
                    create_properties = ofm.get_create_properties(
                                                            properties_stack)
                    properties_stack = ofm.render_and_apply_properties(
                                        create_properties,server,
                                        properties_stack)

                    #No need for CreateTags, in CB these are a function of the 
                    #resource handler and can be driven by looking at a specific
                    #property. What you could do is set the resource handler to 
                    #look at a tagEnv parameter to set the tag value for env, 
                    #but use the PTK to drive the tagEnv parameter
                    #Regenerate the properties stack at the end of each run to 
                    #ensure all updated properties are captured
                    properties_stack = utilities.get_cb_object_properties(server)
                    totalRuns += 1
                return "SUCCESS", "", ""
            else: 
                set_progress(f'More than a single OneFuse_PropertyToolkit'
                             f' value was found, unable to proceed. Number: '
                             f'{len(endpoint_policies)}')
                return "FAILED","","More than one PropertyToolkit value found"
        else:
            set_progress("OneFuse_PropertyToolkit parameter is not set on "
                         "the server, OneFuse Property Toolkit will not be "
                         "executed.")
    else:
        set_progress("Server was not found")
        return "FAILED", "", "Server was not found"
