import json
from common.methods import set_progress
from jobs.models import Job
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, *args, **kwargs):
    for server in job.server_set.all():
        set_progress(f"This plug-in is running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        ad_state = server.get_cfv_for_custom_field("OneFuse_AD_State")
        utilities.verbose_logging(f'object_json: {ad_state}')
        if ad_state and ad_state.value_as_string == 'build': 
            object_json = server.get_cfv_for_custom_field("OneFuse_AD")
            if object_json: 
                object_json = object_json.value_as_string
                mo = json.loads(object_json)
                onefuse_endpoint = mo["endpoint"]
                mo_name = mo["name"]
                mo_id = mo["id"]
                if onefuse_endpoint and mo_id: 
                    set_progress(f"Starting OneFuse AD Move OU. Policy: "
                                f"{mo_name}, Endpoint: "
                                f"{onefuse_endpoint}, AD ID: {mo_id}")
                    #Delete Name Object
                    try: 
                        tracking_id = server.OneFuse_Tracking_Id
                    except: 
                        tracking_id = ""
                    ofm = OneFuseManager(onefuse_endpoint)
                    response_json = ofm.move_ou(mo_id,tracking_id)
                    response_json["endpoint"] = onefuse_endpoint
                    state = response_json["state"]
                    utilities.check_or_create_cf("OneFuse_AD_State")
                    server.set_value_for_custom_field("OneFuse_AD_State", state)
                    utilities.check_or_create_cf("OneFuse_AD")
                    server.set_value_for_custom_field("OneFuse_AD",
                                                    json.dumps(response_json))
                    server.OneFuse_Tracking_Id = response_json["trackingId"]
                    server.save()
                    return_str = f"Move OU was successfully completed for "\
                                f"{server.hostname}"
                    return "SUCCESS",return_str, ""
                else: 
                    set_progress(f"OneFuse AD endpoint or ID was missing, "
                                f"Execution skipped")
                    return "SUCCESS", (f"No OneFuse AD object identified. AD "
                                    f"deletion skipped."), ""
            else: 
                return "FAILURE", "", "OneFuse_AD not set unable to Move OU."
        else: 
            set_progress(f"OneFuse AD state was either missing or not equal "
                         f"to 'Build', Execution skipped")
            return "SUCCESS", (f"Move OU skipped."), ""

