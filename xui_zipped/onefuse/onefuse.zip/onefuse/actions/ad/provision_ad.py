if __name__ == "__main__":
    import os
    import sys
    import django

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
    sys.path.append("/opt/cloudbolt")
    sys.path.append("/var/opt/cloudbolt/proserv")
    django.setup()

import json
from common.methods import set_progress
from xui.onefuse.cb_onefuse_admin import CbOneFuseManager, Utilities
from utilities.logger import ThreadLogger
from jobs.models import Job

logger = ThreadLogger(__name__)


def run(job, **kwargs):
    server = job.server_set.first()
    if server:
        utilities = Utilities(logger)
        set_progress(f"provision_ad running for server {server}")
        logger.debug(f"Dictionary of keyword args passed to this "
                      f"plug-in: {kwargs.items()}")
        hook_point = kwargs.get("hook_point")
        properties_stack = utilities.get_cb_object_properties(server,
                                                              hook_point)
        endpoint_policies = utilities.get_connection_and_policy_values(
            'OneFuse_ADPolicy', properties_stack)
        logger.debug(f'endpoint_policies: {endpoint_policies}')
        if len(endpoint_policies) == 1:
            endpoint_policy = endpoint_policies[0]
            onefuse_endpoint = endpoint_policy["endpoint"]
            policy_name = endpoint_policy["policy"]
            set_progress(f"Starting OneFuse AD Policy: "
                         f"{policy_name}, Endpoint: {onefuse_endpoint}")
            try:
                tracking_id = server.OneFuse_Tracking_Id
            except:
                tracking_id = ""
            ofm = CbOneFuseManager(onefuse_endpoint, logger=logger)
            response_json = ofm.provision_ad(policy_name, properties_stack,
                                                tracking_id)
            response_json["endpoint"] = onefuse_endpoint
            state = response_json["state"]
            utilities.check_or_create_cf("OneFuse_AD_State")
            server.set_value_for_custom_field("OneFuse_AD_State", state)
            utilities.check_or_create_cf("OneFuse_AD")
            server.set_value_for_custom_field("OneFuse_AD",
                                              json.dumps(response_json))
            server.OneFuse_Tracking_Id = response_json["trackingId"]
            server.save()
            set_progress(f"AD object completed for: {server.hostname}")
            return "SUCCESS", "", ""
        elif len(endpoint_policies) > 1:
            set_progress("More than one OneFuse_ADPolicy parameter is set on "
                         "the server, OneFuse AD will not be executed.")
        else:
            set_progress("OneFuse_ADPolicy parameter is not set on "
                         "the server, OneFuse AD will not be executed.")

    else:
        set_progress("Server was not found")
        return "FAILURE", "", "Server was not found"


if __name__ == "__main__":
    job_id = sys.argv[1]
    j = Job.objects.get(id=job_id)
    run = run(j)
    if run[0] == "FAILURE":
        set_progress(run[1])
