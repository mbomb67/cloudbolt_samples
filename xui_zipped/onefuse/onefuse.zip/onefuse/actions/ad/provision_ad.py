import json
from common.methods import set_progress
from jobs.models import Job
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, **kwargs):
    server = job.server_set.first()
    if server:
        set_progress(f"provision_ad running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        hook_point = kwargs.get("hook_point")
        properties_stack = utilities.get_cb_object_properties(server,hook_point)
        endpoint_policies = utilities.get_connection_and_policy_values(
                            'OneFuse_ADPolicy',properties_stack)
        utilities.verbose_logging(f'endpoint_policies: {endpoint_policies}')
        if len(endpoint_policies) == 1:
            endpoint_policy = endpoint_policies[0]
            onefuse_endpoint = endpoint_policy["endpoint"]
            policy_name = endpoint_policy["policy"]
            set_progress(f"Starting OneFuse AD Policy: "
                         f"{policy_name}, Endpoint: {onefuse_endpoint}")
            try: 
                tracking_id = server.OneFuse_Tracking_Id
            except: 
                tracking_id = ""
            ofm = OneFuseManager(onefuse_endpoint)
            response_json = ofm.provision_ad(policy_name,properties_stack, 
                                             tracking_id)  
            response_json["endpoint"] = onefuse_endpoint
            state = response_json["state"]
            utilities.check_or_create_cf("OneFuse_AD_State")
            server.set_value_for_custom_field("OneFuse_AD_State", state)
            utilities.check_or_create_cf("OneFuse_AD")
            server.set_value_for_custom_field("OneFuse_AD",
                                              json.dumps(response_json))
            server.OneFuse_Tracking_Id = response_json["trackingId"]
            server.save()
            set_progress(f"AD object completed for: {server.hostname}")
            return "SUCCESS", "", ""
        elif len(endpoint_policies) > 1:
            set_progress("More than one OneFuse_ADPolicy parameter is set on "
                         "the server, OneFuse AD will not be executed.")
        else:
            set_progress("OneFuse_ADPolicy parameter is not set on "
                         "the server, OneFuse AD will not be executed.")

    else:
        set_progress("Server was not found")
        return "FAILURE", "", "Server was not found"

