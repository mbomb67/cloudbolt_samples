import json
from common.methods import set_progress
from jobs.models import Job
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, *args, **kwargs):
    for server in job.server_set.all():
        set_progress(f"This plug-in is running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        object_json = server.get_cfv_for_custom_field("OneFuse_AD")
        utilities.verbose_logging(f'object_json: {object_json}')
        if object_json: 
            object_json = object_json.value_as_string
            mo = json.loads(object_json)
            onefuse_endpoint = mo["endpoint"]
            mo_name = mo["name"]
            mo_id = mo["id"]
            if onefuse_endpoint and mo_id: 
                utilities.verbose_logging(f"Starting OneFuse Delete AD Object."
                                          f" Policy: {mo_name}, Endpoint: "
                                          f"{onefuse_endpoint}, AD ID: {mo_id}")
                #Delete Name Object
                ofm = OneFuseManager(onefuse_endpoint)
                deleted_obj_name = ofm.deprovision_ad(mo_id)
                return_str = f"AD Computer was successfully deleted from the "\
                             f"OneFuse database. Name: {deleted_obj_name}"
                return "SUCCESS",return_str, ""
            else: 
                set_progress(f"OneFuse AD endpoint or ID was missing, "
                             f"Execution skipped")
                return "SUCCESS", (f"No OneFuse AD object identified. AD "
                                   f"deletion skipped."), ""
        else: 
            set_progress(f"OneFuse AD policy, endpoint or AD was "
                         f"missing, Execution skipped")
            return "SUCCESS", (f"No OneFuse AD ID identified. AD deletion"
                               f" skipped."), ""

