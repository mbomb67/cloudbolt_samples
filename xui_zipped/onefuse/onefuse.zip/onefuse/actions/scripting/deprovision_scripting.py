from common.methods import set_progress
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, **kwargs):
    server = job.server_set.first()
    if server:
        set_progress(f"deprovision_scripting running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        properties_stack = utilities.get_cb_object_properties(server)
        matching_props = utilities.get_matching_properties('OneFuse_Scripting_',
                                                        properties_stack)
        if len(matching_props) > 0:
            matching_props = utilities.sort_deprovision_props(matching_props)
            utilities.verbose_logging(f'matching_props: {matching_props}')
            hostname = server.hostname
            for matching_prop in matching_props:
                id = matching_prop.get("id")
                onefuse_endpoint = matching_prop.get("endpoint")
                utilities.verbose_logging(f'Preparing to deprovision scripting'
                          f' for hostname: {hostname}, suffix: '
                          f'{matching_prop["OneFuse_Suffix"]}, Hook string: '
                          f'{matching_prop["OneFuse_CBHookPointString"]}')
                ofm = OneFuseManager(onefuse_endpoint)
                ofm.deprovision_scripting(id)
                set_progress("Scripting deletion completed.")
            return "SUCCESS", "", ""
        else:
            set_progress("No OneFuse_Scripting_ properties found on the server"
                         ", Deprovision Scripting will not be executed.")
    else:
        set_progress("Server was not found")
        return "FAILURE", "", "Server was not found"

