import json
from common.methods import set_progress
from jobs.models import Job
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, **kwargs):
    server = job.server_set.first()
    if server:
        set_progress(f"provision_scripting running for server {server}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        hook_point = kwargs.get("hook_point")
        
        if hook_point == None:
            #hostname overwrite isn't passing the hook_point in to the job
            hook_point = 'generated_hostname_overwrite'
        properties_stack = utilities.get_cb_object_properties(server,hook_point)
        module_prefix = 'OneFuse_ScriptingPolicy_'
        if hook_point == "generated_hostname_overwrite":
            hook_point_string = "HostnameOverwrite"
        elif hook_point == "pre_create_resource":
            hook_point_string = "PreCreateResource"
        elif hook_point == "pre_application":
            hook_point_string = "PreApplication"
        elif hook_point == "post_provision":
            hook_point_string = "PostProvision"
        else: 
            set_progress("Scripting action launched at an unsupported hook "
                         f"point: {hook_point}. Exiting")
            return "SUCCESS", "", ""
        endpoint_policies = utilities.get_connection_and_policy_values(
                    f'{module_prefix}{hook_point_string}_',properties_stack)
        utilities.verbose_logging(f'endpoint_policies: {endpoint_policies}')
        #Loop through endpoint policies and execute applicable scripts
        if endpoint_policies:
            #Sort scripting policies for hook point alphanumerically on suffix
            endpoint_policies.sort(key=lambda x: x["suffix"], reverse=False)
            for endpoint_policy in endpoint_policies:
                onefuse_endpoint = endpoint_policy["endpoint"]
                policy_name = endpoint_policy["policy"]
                suffix = endpoint_policy["suffix"]
                set_progress(f"Starting OneFuse Scripting Policy: "
                            f"{policy_name}, Endpoint: {onefuse_endpoint}, "
                            f"suffix: {suffix}")
                try: 
                    tracking_id = server.OneFuse_Tracking_Id
                except: 
                    tracking_id = ""
                ofm = OneFuseManager(onefuse_endpoint)
                response_json = ofm.provision_scripting(policy_name,
                                               properties_stack,tracking_id)
                response_json["endpoint"] = onefuse_endpoint
                response_json["OneFuse_CBHookPointString"] = hook_point_string
                response_json["OneFuse_Suffix"] = suffix
                response_json = utilities.delete_output_job_results(
                                            response_json,'scripting')
                script_property = f'OneFuse_Scripting_{suffix}'
                utilities.check_or_create_cf(script_property,"TXT")
                server.set_value_for_custom_field(script_property,
                                                json.dumps(response_json))
                server.OneFuse_Tracking_Id = response_json["trackingId"]
                server.save()
                set_progress(f"OneFuse script execution complete. for policy: "
                             f"{policy_name}")
            return "SUCCESS", "", ""
        else:
            set_progress("OneFuse_ScriptingPolicy_ parameter for hook point: "
                         f"{hook_point} is not set on the server, OneFuse "
                         f"Scripting will not be executed for hook point.")
    else:
        set_progress("Server was not found")
        return "FAILED", "", "Server was not found"

