from common.methods import set_progress
from jobs.models import Job
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, **kwargs):
    resource = job.resource_set.first()
    if resource:
        set_progress(f"teardown ansible tower running for resource {resource}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        properties_stack = utilities.get_cb_object_properties(resource)
        matching_props = utilities.get_matching_properties(
                                    'OneFuse_AnsibleTower',properties_stack)
        if len(matching_props) > 0:
            utilities.verbose_logging(f'matching_props: {matching_props}')
            name = resource.name
            for matching_prop in matching_props:
                id = matching_prop.get("id")
                onefuse_endpoint = matching_prop.get("endpoint")
                utilities.verbose_logging(f'Preparing to deprovision Ansible '
                          f'Tower for resource name: {name}')
                ofm = OneFuseManager(onefuse_endpoint)
                ofm.deprovision_ansible_tower(id)
                set_progress("Ansible Tower deletion completed.")
            return "SUCCESS", "", ""
        else:
            set_progress("No OneFuse_AnsibleTower_ properties found on the server"
                         ", Deprovision Ansible Tower will not be executed.")
    else:
        set_progress("Resource was not found")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        return "FAILURE", "", "Resource was not found"
