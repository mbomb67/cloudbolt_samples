import json
from common.methods import set_progress
from jobs.models import Job
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

ONEFUSE_ENDPOINT = '{{resource.onefuse_endpoint}}'
POLICY_NAME = '{{resource.policy_name}}'
HOSTS = '{{resource.hosts}}'
LIMIT = '{{resource.limit}}'

def run(job, **kwargs):
    resource = job.resource_set.first()
    if resource:
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                    f"plug-in: {kwargs.items()}")
        #Loop through endpoint policies and execute applicable AT policies
        #Sort AT policies for hook point alphanumerically on suffix
        properties_stack = utilities.get_cb_object_properties(resource)
        set_progress(f"Starting OneFuse AT Policy: {POLICY_NAME}, "
                    f"Endpoint: {ONEFUSE_ENDPOINT}, HOSTS: {HOSTS}, "
                    f"LIMIT: {LIMIT}, properties: {properties_stack}")
        ofm = OneFuseManager(ONEFUSE_ENDPOINT)
        response_json = ofm.provision_ansible_tower(POLICY_NAME,
                            properties_stack,HOSTS,LIMIT,None)
        response_json["endpoint"] = ONEFUSE_ENDPOINT
        output_property = f'OneFuse_AnsibleTower'
        response_json = utilities.delete_output_job_results(
                                    response_json,'ansible_tower')
        utilities.check_or_create_cf(output_property,"TXT")
        resource.set_value_for_custom_field(output_property,
                                        json.dumps(response_json))
        resource.OneFuse_Tracking_Id = response_json["trackingId"]
        resource.save()
        set_progress(f"OneFuse Ansible Tower execution complete. for "
                        f"policy: {POLICY_NAME}")
        return "SUCCESS", "", ""
    else: 
        return "FAILURE",f"Resource could not be found. {kwargs.items()}",""



