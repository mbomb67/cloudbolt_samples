if __name__ == '__main__':
    import django

    django.setup()

import sys
import re
import json
from common.methods import set_progress
from xui.onefuse.configuration.globals import (
    IGNORE_PROPERTIES,
    UPSTREAM_PROPERTY,
    STATIC_PROPERTY_SET_PREFIX
)
from xui.onefuse import utilities
from xui.onefuse.api_wrapper import OneFuseConnector


class OneFuseManager(OneFuseConnector):
    """
    This class facilitates OneFuse Module requests.
    """

    def __init__(self, name: str, verify_certs: bool = None,
                 tracking_id: str = ""):
        super().__init__(name, verify_certs, tracking_id)

    # AD Functions:
    def provision_ad(self, policy_name, properties_stack, tracking_id):
        # Get AD Policy by Name
        rendered_policy_name = utilities.render(policy_name, properties_stack,
                                                self)
        policy_path = 'microsoftADPolicies'
        policy_json = utilities.get_policy_by_name(self, policy_path,
                                                   rendered_policy_name)
        links = policy_json["_links"]
        policy_url = links["self"]["href"]
        workspace_url = links["workspace"]["href"]
        # Request AD
        name = properties_stack["hostname"]
        template = {
            "policy": policy_url,
            "templateProperties": properties_stack,
            "workspace": workspace_url,
            "name": name,
        }
        url = "/microsoftADComputerAccounts/"
        response_json = utilities.request(self, url, template, tracking_id)
        return response_json

    def deprovision_ad(self, ad_id):
        path = f'/microsoftADComputerAccounts/{ad_id}/'
        utilities.deprovision_mo(self, path)
        return path

    def move_ou(self, ad_id, tracking_id):
        path = f'/microsoftADComputerAccounts/{ad_id}/'
        get_response = self.get(path)
        get_response.raise_for_status()
        get_response = get_response.json()
        final_ou = get_response["finalOu"]
        name = get_response["name"]
        links = get_response["_links"]
        workspace_url = links["workspace"]["href"]
        template = {
            "workspace": workspace_url,
            "state": "final"
        }
        set_progress(f'Moving AD object: {name} to final OU: {final_ou}')
        response_json = utilities.request(self, path, template, tracking_id,
                                          "put")
        set_progress(f"AD object was successfully moved to the final OU. "
                     f"AD: {name}, OU: {final_ou}")
        return response_json

    # Ansible Tower Functions
    def provision_ansible_tower(self, policy_name, properties_stack, hosts,
                                limit, tracking_id):
        # Get Ansible Tower Policy by Name
        rendered_policy_name = utilities.render(policy_name, properties_stack,
                                                self)
        policy_path = 'ansibleTowerPolicies'
        policy_json = utilities.get_policy_by_name(self, policy_path,
                                                   rendered_policy_name)
        links = policy_json["_links"]
        policy_url = links["self"]["href"]
        workspace_url = links["workspace"]["href"]
        # Render hosts and limit
        hosts_arr = []
        if hosts:
            rendered_hosts = utilities.render(hosts, properties_stack, self)
            for host in rendered_hosts.split(','):
                hosts_arr.append(host.strip())
        if limit:
            rendered_limit = utilities.render(limit, properties_stack, self)
        else:
            rendered_limit = ''
        # Request Ansible Tower
        template = {
            "policy": policy_url,
            "workspace": workspace_url,
            "templateProperties": properties_stack,
            "hosts": hosts_arr,
            "limit": rendered_limit
        }
        path = "/ansibleTowerDeployments/"
        response_json = utilities.request(self, path, template,
                                          tracking_id)
        return response_json

    def deprovision_ansible_tower(self, at_id):
        path = f'/ansibleTowerDeployments/{at_id}/'
        utilities.deprovision_mo(self, path)
        return path

    # DNS Functions
    def provision_dns(self, policy_name, properties_stack, ip_address,
                      zones, tracking_id=""):
        # Get DNS Policy by Name
        rendered_policy_name = utilities.render(policy_name, properties_stack,
                                                self)
        policy_path = 'dnsPolicies'
        policy_json = utilities.get_policy_by_name(self, policy_path,
                                                   rendered_policy_name)
        links = policy_json["_links"]
        policy_url = links["self"]["href"]
        workspace_url = links["workspace"]["href"]
        rendered_zones = []
        for zone in zones:
            rendered_zone = utilities.render(zone, properties_stack, self)
            rendered_zones.append(rendered_zone)
        # Request DNS
        hostname = properties_stack["hostname"]
        value = ip_address
        template = {
            "policy": policy_url,
            "templateProperties": properties_stack,
            "workspace": workspace_url,
            "name": hostname,
            "value": value,
            "zones": rendered_zones
        }
        path = "/dnsReservations/"
        response_json = utilities.request(self, path, template, tracking_id)
        return response_json

    def deprovision_dns(self, dns_id):
        path = f'/dnsReservations/{dns_id}/'
        utilities.deprovision_mo(self, path)
        return path

    # IPAM Functions
    def provision_ipam(self, policy_name, properties_stack,
                       tracking_id=""):
        # Get IPAM Policy by Name
        rendered_policy_name = utilities.render(policy_name, properties_stack,
                                                self)
        policy_path = 'ipamPolicies'
        policy_json = utilities.get_policy_by_name(self, policy_path,
                                                   rendered_policy_name)
        links = policy_json["_links"]
        policy_url = links["self"]["href"]
        workspace_url = links["workspace"]["href"]
        # Request IPAM
        hostname = properties_stack["hostname"]
        template = {
            "policy": policy_url,
            "templateProperties": properties_stack,
            "workspace": workspace_url,
            "hostname": hostname
        }
        path = "/ipamReservations/"
        response_json = utilities.request(self, path, template, tracking_id)
        return response_json

    def deprovision_ipam(self, ipam_id):
        path = f'/ipamReservations/{ipam_id}/'
        utilities.deprovision_mo(self, path)
        return path

    # Naming Functions
    def provision_naming(self, policy_name, properties_stack,
                         tracking_id=""):
        # Get Naming Policy by Name
        rendered_policy_name = utilities.render(policy_name, properties_stack,
                                                self)
        policy_path = 'namingPolicies'
        policy_json = utilities.get_policy_by_name(self, policy_path,
                                                   rendered_policy_name)
        links = policy_json["_links"]
        policy_url = links["self"]["href"]
        workspace_url = links["workspace"]["href"]
        # Request Machine Custom Name
        template = {
            "policy": policy_url,
            "templateProperties": properties_stack,
            "workspace": workspace_url,
        }
        path = "/customNames/"
        response_json = utilities.request(self, path, template,
                                          tracking_id)
        return response_json

    def deprovision_naming(self, name_id):
        path = f'/customNames/{name_id}/'
        utilities.deprovision_mo(self, path)
        return path

    # Property Toolkit
    def get_sps_properties(self, resource):
        try:
            custom_fields = resource.get_cf_values_as_dict()
            # Get Unsorted list of keys that match OneFuse_SPS_
            sps_keys = []
            pattern = re.compile(STATIC_PROPERTY_SET_PREFIX)
            for key in custom_fields.keys():
                result = pattern.match(key)
                if result is not None:
                    sps_keys.append(key)

            # Sort list alphanumerically.
            sps_keys.sort()

            # Gather Properties
            sps_properties = {}
            for key in sps_keys:
                sps_name = custom_fields[key]
                sps_json = self.get_sps_by_name(sps_name)
                props = sps_json["properties"]
                for key in props.keys():
                    if key == UPSTREAM_PROPERTY:
                        upstream_value = props[key]
                        for upstream_key in upstream_value.keys():
                            sps_properties[upstream_key] = upstream_value[
                                upstream_key]
                    else:
                        try:
                            IGNORE_PROPERTIES.index(key)
                            utilities.verbose_logging(
                                f'An upstream ignore value '
                                f'was found, ignoring property. '
                                f'Ignore property: {key}')
                        except:
                            sps_properties[key] = props[key]
        except Exception:
            raise Exception(f'Error: {sys.exc_info()[0]}. {sys.exc_info()[1]}, '
                            f'line: {sys.exc_info()[2].tb_lineno}')

        return sps_properties

    def get_sps_by_name(self, sps_name):
        path = f'/propertySets/?filter=name.iexact:"{sps_name}"'
        response = self.get(path)
        response.raise_for_status()
        sps_json = response.json()

        if sps_json["count"] > 1:
            raise Exception(f"More than one Static Property Set was returned "
                            f"matching the name: {sps_name}. Response: "
                            f"{json.dumps(sps_json)}")

        if sps_json["count"] == 0:
            raise Exception(
                f"No static property sets were returned matching the"
                f" name: {sps_name}. Response: "
                f"{json.dumps(sps_json)}")
        sps_json = sps_json["_embedded"]["propertySets"][0]
        return sps_json

    def render_and_apply_properties(self, properties, resource,
                                    properties_stack):
        for key in properties.keys():
            rendered_key = utilities.render(key, properties_stack, self)
            if type(properties[key]) == dict:
                props_key = json.dumps(properties[key])
            else:
                props_key = properties[key]
            rendered_value = utilities.render(props_key, properties_stack,
                                              self)
            if (rendered_key is not None and rendered_key != "" and
                    rendered_value is not None and rendered_value != ""):
                if rendered_key == 'os_build':
                    from externalcontent.models import OSBuild
                    current_os_build = resource.os_build
                    if current_os_build.os_family:
                        print("test")
                    os_build = OSBuild.objects.get(name=rendered_value)
                    utilities.verbose_logging(f'Setting OS build ID to: '
                                              f'{os_build.id}')
                    # Update OS Build
                    resource.os_build_id = os_build.id
                    resource.save()
                    utilities.verbose_logging(f'Setting OS Family ID to: '
                                              f'{os_build.os_family.id}')
                    # Update OS Family
                    resource.os_family_id = os_build.os_family.id
                    resource.save()
                    # Update OS Credentials
                    os_build_attrs = os_build.osba_for_resource_handler(
                        resource.resource_handler)
                    resource.username = os_build_attrs.username
                    resource.password = os_build_attrs.password
                    resource.save()
                elif rendered_key == 'environment':
                    # Not working. Environment appears to change, but when VM
                    # builds, it is set to original environment
                    from infrastructure.models import Environment
                    resource.environment = Environment.objects.filter(
                        name=rendered_value).first()
                else:
                    try:
                        resource.set_value_for_custom_field(rendered_key,
                                                            rendered_value)
                    except:
                        # If adding param to the resource fails, try to create
                        utilities.check_or_create_cf(rendered_key)
                        resource.set_value_for_custom_field(rendered_key,
                                                            rendered_value)
                    utilities.verbose_logging(
                        f'Setting property: {rendered_key} to: '
                        f'{rendered_value}')
                properties_stack[rendered_key] = rendered_value
        resource.save()
        return properties_stack

    def get_create_properties(self, properties_stack):
        create_properties = {}
        pattern = re.compile("OneFuse_CreateProperties_")
        for key in properties_stack.keys():
            result = pattern.match(key)
            if result is not None:
                utilities.verbose_logging(f'Starting JSON parse of key: {key}, '
                                          f'value: {properties_stack[key]}')
                value_obj = properties_stack[key]
                utilities.verbose_logging(f'Create Props Object: {value_obj}')
                if type(value_obj) == str:
                    value_obj = json.loads(value_obj)
                if value_obj["key"] and value_obj["value"]:
                    create_properties[value_obj["key"]] = value_obj["value"]
        return create_properties

    # Scripting
    def provision_scripting(self, policy_name, properties_stack,
                            tracking_id):
        # Get Scripting Policy by Name
        rendered_policy_name = utilities.render(policy_name, properties_stack,
                                                self)
        policy_path = 'scriptingPolicies'
        policy_json = utilities.get_policy_by_name(self, policy_path,
                                                   rendered_policy_name)
        links = policy_json["_links"]
        policy_url = links["self"]["href"]
        workspace_url = links["workspace"]["href"]
        # Request Scripting
        template = {
            "policy": policy_url,
            "templateProperties": properties_stack,
            "workspace": workspace_url,
        }
        path = "/scriptingDeployments/"
        response_json = utilities.request(self, path, template,
                                          tracking_id)
        return response_json

    def deprovision_scripting(self, script_id):
        path = f'/scriptingDeployments/{script_id}/'
        utilities.deprovision_mo(self, path)
        return path

    # ServiceNow CMDB Functions
    def provision_cmdb(self, policy_name, properties_stack,
                       tracking_id):
        # Get CMDB Policy by Name
        rendered_policy_name = utilities.render(policy_name, properties_stack,
                                                self)
        policy_path = 'servicenowCMDBPolicies'
        policy_json = utilities.get_policy_by_name(self, policy_path,
                                                   rendered_policy_name)
        links = policy_json["_links"]
        policy_url = links["self"]["href"]
        workspace_url = links["workspace"]["href"]
        # Request Scripting
        template = {
            "policy": policy_url,
            "templateProperties": properties_stack,
            "workspace": workspace_url,
        }
        path = "/servicenowCMDBDeployments/"
        response_json = utilities.request(self, path, template,
                                          tracking_id)
        return response_json

    def update_cmdb(self, properties_stack, cmdb_id, tracking_id):
        # Get Existing Object
        path = f'/servicenowCMDBDeployments/{cmdb_id}/'
        current_response = self.get(path)
        current_response.raise_for_status()
        current_json = current_response.json()
        # Template
        template = {
            "policy": current_json["_links"]["policy"]["href"],
            "templateProperties": properties_stack,
            "workspace": current_json["_links"]["workspace"]["href"],
        }
        # Send Put request
        response_json = utilities.request(self, path, template, tracking_id,
                                          'put')
        return response_json

    def deprovision_cmdb(self, cmdb_id):
        path = f'/servicenowCMDBDeployments/{cmdb_id}/'
        utilities.deprovision_mo(self, path)
        return path


if __name__ == '__main__':
    with OneFuseManager('onefuse') as onefuse:
        response = onefuse.get('/namingPolicies/')

    print(json.dumps(response.json(), indent=True))
