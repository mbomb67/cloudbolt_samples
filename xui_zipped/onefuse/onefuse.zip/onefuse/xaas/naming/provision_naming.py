from common.methods import set_progress
import json
from xui.onefuse import utilities
from xui.onefuse.onefuse_admin import OneFuseManager

def run(job, *args, **kwargs):
    resource = job.resource_set.first()
    if resource:
        set_progress(f"This plug-in is running for resource {resource}")
        utilities.verbose_logging(f"Dictionary of keyword args passed to this "
                                  f"plug-in: {kwargs.items()}")
        onefuse_endpoint = "{{onefuse_endpoint}}"
        naming_policy_name = "{{naming_policy_name}}"
        tracking_id = "{{OneFuse_Tracking_Id}}"
        set_progress(f"Starting OneFuse Naming Policy: "
                    f"{naming_policy_name}, Endpoint: {onefuse_endpoint}")
        ofm = OneFuseManager(onefuse_endpoint)
        response_json = ofm.provision_naming(naming_policy_name,resource, 
                                            tracking_id)            
        resource_name = response_json.get("name")
        resource.name = resource_name
        utilities.check_or_create_cf("OneFuse_Naming_Resource")
        response_json["endpoint"] = onefuse_endpoint
        resource.OneFuse_Naming_Resource = json.dumps(response_json)
        resource.OneFuse_Tracking_Id = response_json.get("trackingId")
        resource.save()
        set_progress(f"Resource name being set to: {resource.name}")
        return "SUCCESS", resource_name, ""
    else: 
        set_progress("Resource was not found")
