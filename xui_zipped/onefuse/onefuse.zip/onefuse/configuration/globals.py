from os import path

# Logging
VERBOSE_LOGGING = True

# OneFuse Certificate Validation
VERIFY_CERTS = False

# XUI Global Configs
XUI_NAME = __name__.split('.')[1]
# Returns the path of the parent XUI dir
XUI_PATH = path.dirname(path.dirname(path.abspath(__file__)))
# The path of the XUI folder
ROOT_PATH = path.dirname(XUI_PATH)

# Async Timeouts (in minutes)
ONEFUSE_ASYNC_TIMEOUT_NAMING = 10
ONEFUSE_ASYNC_TIMEOUT_IPAM = 10
ONEFUSE_ASYNC_TIMEOUT_DNS = 10
ONEFUSE_ASYNC_TIMEOUT_AD = 15
ONEFUSE_ASYNC_TIMEOUT_SCRIPTING = 90
ONEFUSE_ASYNC_TIMEOUT_ANSIBLETOWER = 120
ONEFUSE_ASYNC_TIMEOUT_OTHER = 5

# Upstream Provider
UPSTREAM_VERSION = '1.3.0'

# Property Toolkit
STATIC_PROPERTY_SET_PREFIX = 'OneFuse_SPS_'  # Global Prefix
MAX_RUNS = 3
IGNORE_PROPERTIES = ["OneFuse_VRA7_Props", "OneFuse_VRA8_Props",
                     "OneFuse_TF_Props"]
UPSTREAM_PROPERTY = "OneFuse_CB_Props"
