####### User changeable variables: ########
#You can uncomment and set any of the following variables if desired
'''
Connection Info Variables. The following variables (if set) will create a
new Connection Info in CB to connect to OneFuse. If using, ALL variables 
must be uncommented and set
'''
connectioninfo_name="" #onefuse
onefuse_fqdn="" #onefuse.local
onefuse_user="" #username
onefuse_pass="" #password
onefuse_port="" #443
onefuse_protocol="" #https



####### End User variables ########

#module imports
from os import path
import os
import sys
import django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
sys.path.append("/opt/cloudbolt")
sys.path.append("/var/opt/cloudbolt/proserv")
django.setup()
from xui.onefuse import utilities
from infrastructure.models import CustomField
from common.methods import set_progress
from cbhooks.models import CloudBoltHook
from xui.onefuse.configuration.globals import XUI_PATH
from utilities.templatetags.helper_tags import render_simple_link
from django.utils.html import format_html

def create_setup_action():
    action_data = {'name': 'OneFuse Configuration Script',
                   'description': 'Script execution to configure the OneFuse Plugin for CloudBolt',
                   'source_code_url': f'file://{XUI_PATH}/configuration/setup.py'
                  }
    
    action_name = action_data.pop('action_name')

    action, created = CloudBoltHook.objects.get_or_create(
        name=action_name,
        defaults=action_data
    )

    job_list = action.run_as_job()
    job = job_list[0]
    msg = format_html(
        "Job {} has been created.",
        render_simple_link(job),
    )

    return msg

def create_onefuse_params():
    #Create Parameters for modules if not exist
    cb_params = [
        {
            "names":["OneFuse_ADPolicy"],
            "placeholder":"onefuse_endpoint:ad_policy_name",
            "description":"OneFuse Active Directory Policy"
        },
        {
            "names":["OneFuse_DnsPolicy_Nic0","OneFuse_DnsPolicy_Nic1",
                     "OneFuse_DnsPolicy_Nic2","OneFuse_DnsPolicy_Nic3",
                     "OneFuse_DnsPolicy_Nic4","OneFuse_DnsPolicy_Nic5", 
                     "OneFuse_DnsPolicy_Nic6","OneFuse_DnsPolicy_Nic7",
                     "OneFuse_DnsPolicy_Nic8","OneFuse_DnsPolicy_Nic9"],
            "placeholder":"onefuse_endpoint:dns_policy_name:zone1:zone2",
            "description":"OneFuse Dns Policy"
        },
        {
            "names":["OneFuse_IpamPolicy_Nic0","OneFuse_IpamPolicy_Nic1",
                     "OneFuse_IpamPolicy_Nic2","OneFuse_IpamPolicy_Nic3",
                     "OneFuse_IpamPolicy_Nic4","OneFuse_IpamPolicy_Nic5", 
                     "OneFuse_IpamPolicy_Nic6","OneFuse_IpamPolicy_Nic7",
                     "OneFuse_IpamPolicy_Nic8","OneFuse_IpamPolicy_Nic9"],
            "placeholder":"onefuse_endpoint:ipam_policy_name",
            "description":"OneFuse IPAM Policy"
        },
        {
            "names":["OneFuse_NamingPolicy"],
            "placeholder":"onefuse_endpoint:naming_policy_name",
            "description":"OneFuse Naming Policy"
        },
        {
            "names":["OneFuse_PropertyToolkit"],
            "placeholder":"onefuse_endpoint:true",
            "description":"Property to enable OneFuse Property Toolkit"
        },
        {
            "names":["OneFuse_Tracking_Id"],
            "placeholder":"tracking_id",
            "description":"OneFuse Tracking ID Parameter."
        },
        {
            "names":["OneFuse_ServiceNowCmdbPolicy"],
            "placeholder":"onefuse:linux",
            "description":"OneFuse ServiceNow CMDB Policy"
        },
    ]

    for cb_param in cb_params:
        for param_name in cb_param["names"]:
            set_progress(f'Creating or updating param: {param_name}')
            utilities.check_or_create_cf(param_name)
            cf = CustomField.objects.get(name=param_name)
            cf.required = True
            cf.placeholder = cb_param["placeholder"]
            cf.description = cb_param["description"]
            cf.save()


def create_onefuse_actions():
    from cbhooks.models import CloudBoltHook,HookPointAction,HookPoint
    #Create actions if not exist
    from xui.onefuse.configuration.globals import XUI_PATH
    new_actions = [
        {
            "name": "OneFuse - Property Toolkit",
            "source_code_url": f"file://{XUI_PATH}/actions/propertytoolkit/provision_ptk.py",
            "states":[
                {
                    "hook_point": "generated_hostname_overwrite",
                    "run_seq":1000
                },
                {
                    "hook_point": "pre_create_resource",
                    "run_seq":1000
                },
                {
                    "hook_point": "pre_application",
                    "run_seq":1000
                },
                {
                    "hook_point": "post_provision",
                    "run_seq":1000,
                    "run_on_statuses":"SUCCESS,WARNING"
                }
            ]
        },
        {
            "name": "OneFuse - Provision Scripting",
            "source_code_url": f"file://{XUI_PATH}/actions/scripting/provision_scripting.py",
            "states":[
                {
                    "hook_point": "generated_hostname_overwrite",
                    "run_seq":1005
                },
                {
                    "hook_point": "pre_create_resource",
                    "run_seq":1005
                },
                {
                    "hook_point": "pre_application",
                    "run_seq":1005
                },
                {
                    "hook_point": "post_provision",
                    "run_seq":1005,
                    "run_on_statuses":"SUCCESS,WARNING"
                }
            ]
        },
        {
            "name": "OneFuse - Provision Ansible Tower",
            "source_code_url": f"file://{XUI_PATH}/actions/ansible_tower/provision_ansible_tower.py",
            "states":[
                {
                    "hook_point": "generated_hostname_overwrite",
                    "run_seq":1010
                },
                {
                    "hook_point": "pre_create_resource",
                    "run_seq":1010
                },
                {
                    "hook_point": "pre_application",
                    "run_seq":1010
                },
                {
                    "hook_point": "post_provision",
                    "run_seq":1010,
                    "run_on_statuses":"SUCCESS,WARNING"
                }
            ]
        },
        {
            "name": "OneFuse - Provision Naming",
            "source_code_url": f"file://{XUI_PATH}/actions/naming/provision_naming.py",
            "states":[
                {
                    "hook_point": "generated_hostname_overwrite",
                    "run_seq":1150
                }
            ]
        },
        {
            "name": "OneFuse - Provision IPAM",
            "source_code_url": f"file://{XUI_PATH}/actions/ipam/provision_ipam.py",
            "states":[
                {
                    "hook_point": "pre_create_resource",
                    "run_seq":1200
                }
            ]
        },
        {
            "name": "OneFuse - Provision DNS",
            "source_code_url": f"file://{XUI_PATH}/actions/dns/provision_dns.py",
            "states":[
                {
                    "hook_point": "pre_create_resource",
                    "run_seq":1300
                }
            ]
        },
        {
            "name": "OneFuse - Provision AD",
            "source_code_url": f"file://{XUI_PATH}/actions/ad/provision_ad.py",
            "states": [
                {
                    "hook_point": "pre_create_resource",
                    "run_seq":1500
                }
            ]
        },
        {
            "name": "OneFuse - Move OU - AD",
            "source_code_url": f"file://{XUI_PATH}/actions/ad/move_ou.py",
            "states":[
                {
                    "hook_point": "post_provision",
                    "run_seq":1500,
                    "run_on_statuses":"SUCCESS,WARNING"
                }
            ]
        },
        {
            "name": "OneFuse - Provision ServiceNow CMDB",
            "source_code_url": f"file://{XUI_PATH}/actions/servicenow/provision_cmdb.py",
            "states":[
                {
                    "hook_point": "post_provision",
                    "run_seq":1600,
                    "run_on_statuses":"SUCCESS,WARNING"
                }
            ]
        },
        #{
        #    "name": "OneFuse - Provision IPAM - Preconfigure",
        #    "source_code_url": f"file://{XUI_PATH}/actions/ipam/provision_ipam_preconfig.py",
        #    "states":[
        #        "pre_networkconfig"
        #    ]
        #},
        {
            "name": "OneFuse - Update ServiceNow CMDB",
            "source_code_url": f"file://{XUI_PATH}/actions/servicenow/update_cmdb.py",
            "states":[
                {
                    "hook_point": "post_servermodification",
                    "run_seq":1600,
                    "run_on_statuses":"SUCCESS,WARNING"
                }
            ]
        },
        {
            "name": "OneFuse - De-Provision Scripting",
            "source_code_url": f"file://{XUI_PATH}/actions/scripting/deprovision_scripting.py",
            "states":[
                {
                    "hook_point": "post_decom",
                    "run_seq":10
                }
            ]
        },
        {
            "name": "OneFuse - De-Provision Ansible Tower",
            "source_code_url": f"file://{XUI_PATH}/actions/ansible_tower/deprovision_ansible_tower.py",
            "states":[
                {
                    "hook_point": "post_decom",
                    "run_seq":15
                }
            ]
        },
                {
            "name": "OneFuse - De-Provision ServiceNow CMDB",
            "source_code_url": f"file://{XUI_PATH}/actions/servicenow/deprovision_cmdb.py",
            "states":[
                {
                    "hook_point": "post_decom",
                    "run_seq":1100
                }
            ]
        },
        {
            "name": "OneFuse - De-Provision AD",
            "source_code_url": f"file://{XUI_PATH}/actions/ad/deprovision_ad.py",
            "states":[
                {
                    "hook_point": "post_decom",
                    "run_seq":1200
                }
            ]
        },
        {
            "name": "OneFuse - De-Provision DNS",
            "source_code_url": f"file://{XUI_PATH}/actions/dns/deprovision_dns.py",
            "states":[
                {
                    "hook_point": "post_decom",
                    "run_seq":1300
                }
            ]
        },
        {
            "name": "OneFuse - De-Provision IPAM",
            "source_code_url": f"file://{XUI_PATH}/actions/ipam/deprovision_ipam.py",
            "states":[
                {
                    "hook_point": "post_decom",
                    "run_seq":1400
                }
            ]
        },
        {
            "name": "OneFuse - De-Provision Naming",
            "source_code_url": f"file://{XUI_PATH}/actions/naming/deprovision_naming.py",
            "states":[
                {
                    "hook_point": "post_decom",
                    "run_seq":1500
                }
            ]
        }
    ]

    for new_action in new_actions: 
        #Create Action (CloudBoltHook)
        try: 
            hook = CloudBoltHook.objects.get(name=new_action["name"])
            set_progress(f'Hook already exists: {new_action["name"]}')
            hook.source_code_url=new_action["source_code_url"]
        except: 
            set_progress(f'Hook does not exist, creating: {new_action["name"]}')
            hook = CloudBoltHook(
                name = new_action["name"],
                source_code_url=new_action["source_code_url"]
            )
        hook.description = "OneFuse Plugin Action"
        hook.shared = True
        hook.save()
        
        #Create HookPointAction
        set_progress(f'Starting hook point action creation for {new_action["name"]}')
        for state in new_action["states"]:
            set_progress(f'Starting state: {state["hook_point"]}')
            hp_id = HookPoint.objects.get(name=state["hook_point"]).id
            try: 
                hpa = HookPointAction.objects.get(
                    name=new_action["name"],
                    hook=hook,
                    hook_point_id=hp_id
                )
                set_progress(f'State exists: {state["hook_point"]}')
            except:
                set_progress(f'State does not exist, creating: {state["hook_point"]}')
                hpa = HookPointAction(
                    name=new_action["name"],
                    hook=hook,
                    hook_point_id=hp_id
                )
            hpa.enabled = True
            hpa.continue_on_failure = False
            hpa.run_seq=state["run_seq"]
            if state["hook_point"] == "post_provision":
                try: 
                    hpa.run_on_statuses = state["run_on_statuses"]
                except:
                    pass
            hpa.save()

    #Ensure that the Automatically decom server when provisioning fails HPA
    #Runs last (after all OneFuse)
    hpa_name = 'Automatically decom server when provisioning fails'
    run_seq = 2000
    try: 
        hpa = HookPointAction.objects.get(
            name=hpa_name,
        )
        set_progress(f'Updating HPA: {hpa_name} to run_seq: {run_seq}')
        hpa.run_seq=run_seq
        hpa.save()
    except:
        set_progress(f'"{hpa_name}" does not exist, ignoring.')
        pass
    #Create HookPointActions for each action
    #Looking in to programmatic way to accomplish this and previous step...

#Create ConnectionInfo
def create_connection_info():
    try: 
        from utilities.models import ConnectionInfo
        if (connectioninfo_name and onefuse_fqdn and onefuse_user and 
            onefuse_pass and onefuse_port and onefuse_protocol): 
            #Check to see if connection info exists before creating. 
            conn_info = ConnectionInfo.objects.filter(name=connectioninfo_name)
            if len(conn_info == 0):
                conn_info = ConnectionInfo()
                conn_info.name = connectioninfo_name
                conn_info.ip = onefuse_fqdn
                conn_info.username = onefuse_user
                conn_info.password = onefuse_pass
                conn_info.port = onefuse_port
                conn_info.protocol = onefuse_protocol
            else: 
                set_progress("Existing Connection info found. Resolve and try again.")
        else: 
            set_progress("One of the Connection Info variables was not set, skipping")
    except: 
        set_progress("One of the Connection Info variables was not set, skipping")



#def run(job, logger=None, **kwargs):
def run(**kwargs):
    #set_progress(f'Starting OneFuse Configuration Script')
    create_onefuse_params()
    create_onefuse_actions()

run()