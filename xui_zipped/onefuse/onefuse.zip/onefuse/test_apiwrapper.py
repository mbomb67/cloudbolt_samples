from django.test import TestCase


class TestOneFuseConnector(TestCase):
    pass
