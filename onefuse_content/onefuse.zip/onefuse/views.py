from django.contrib import messages
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django.utils.html import format_html
from django.utils.translation import ugettext as _

from c2_wrapper import create_hook
from cbhooks.models import CloudBoltHook
from extensions.views import admin_extension
from tags.models import CloudBoltTag
from utilities.permissions import cbadmin_required
from utilities.decorators import dialog_view
from utilities.models import ConnectionInfo
from utilities.templatetags import helper_tags


def get_docstring():
    return """
The OneFuse XUI for CloudBolt allows for the execution of OneFuse Codeless 
Integrations during the lifecycle of a CloudBolt Blueprint. This XUI relies
on the OneFuse Python Plugin (https://pypi.org/project/onefuse/) which will 
be installed during the setup step.

Installation Instructions:
1. Install the XUI in CloudBolt. The onefuse directory should end up at:
    /var/opt/cloudbolt/proserv/xui/onefuse
2. Restart Apache
    > systemctl restart httpd
2. Create a Connection Info for onefuse. This must be labelled as 'onefuse'
3. Execute the Configuration script.
    > python /var/opt/cloudbolt/proserv/xui/onefuse/configuration/setup.py

OneFuse Parameter usage ('name' : 'value_format'):
    'OneFuse_AnsibleTowerPolicy_<executionstring>_<uniqueName>' : '<onefusehost>:<policyname>:<hosts>:<limit>'
    'OneFuse_DnsPolicy_Nic<#>' : '<onefusehost>:<policyname>:<dnszones>'
    'OneFuse_IpamPolicy_Nic<#>' : '<onefusehost>:<policyname>'
    'OneFuse_ADPolicy' : '<onefusehost>:<policyname>'
    'OneFuse_NamingPolicy' : '<onefusehost>:<policyname>'
    Property Toolkit properties:
        'OneFuse_PropertyToolkit' : '<onefusehost>:true'
        'OneFuse_SPS_<uniqueName>' : '<staticpropertysetname>'
        'OneFuse_CreateProperties_<uniqueName>' : '{"key":"<key>","value":"<value>"}'
    'OneFuse_ScriptingPolicy_<executionstring>_<uniqueName>' : '<onefusehost>:<policyname>'
    'OneFuse_ServiceNowCmdbPolicy_<executionstring>_<uniqueName>' : '<onefusehost>:<policyname>'
    'OneFuse_PluggableModulePolicy_<executionstring>_<uniqueName>' : '<onefusehost>:<policyname>'

    Valid Execution Strings for Ansible Tower and Scripting:
        HostnameOverwrite
        PreCreateResource
        PreApplication (only valid when configuration manager used)
        PostProvision

"""


def get_onefuse_connection_infos():
    tags = CloudBoltTag.objects.filter(name='onefuse')
    connection_infos = []
    for tag in tags:
        conn_infos = ConnectionInfo.objects.filter(labels=tag)
        for conn_info in conn_infos:
            connection_infos.append(conn_info)
    return connection_infos


@admin_extension(title="OneFuse Integration",
                 description="OneFuse integration library for CloudBolt "
                             "scripts and plugins.")
def onefuse_admin(request, **kwargs):
    context = {
        'docstring': get_docstring(),
        'a': 'b',
        'connection_infos': get_onefuse_connection_infos()
    }
    return render(request, 'onefuse/templates/onefuse_admin.html',
                  context=context)


@dialog_view
def setup_onefuse(request):
    """
    View for launching the OneFuse setup script.
    """
    if request.method == 'POST':
        hook = CloudBoltHook.objects.get(name="OneFuse CloudBolt Plugin "
                                              "Configuration")
        job = hook.run_as_job()[0]
        msg = format_html(
            _("Job {job_name} has been created to check rule(s).").format(
                job_name=helper_tags.render_simple_link(job)
            )
        )

        messages.info(request, msg)
        return HttpResponseRedirect('/onefuse_admin')
    else:
        create_onefuse_setup_hook()
        content = (
            'Setup OneFuse?')
        action_url = reverse(
            'setup_onefuse')

        return {
            'title': 'Confirm OneFuse Setup',
            'content': content,
            'use_ajax': True,
            'action_url': action_url,
            'submit': 'Setup',
        }


@dialog_view
def create_onefuse_endpoint(request):
    """
    View for launching the OneFuse setup script.
    """
    if request.method == 'POST':
        hook = CloudBoltHook.objects.get(name="OneFuse CloudBolt Plugin "
                                              "Configuration")
        job = hook.run_as_job()[0]
        msg = format_html(
            _("Job {job_name} has been created to check rule(s).").format(
                job_name=helper_tags.render_simple_link(job)
            )
        )

        messages.info(request, msg)
        return HttpResponseRedirect('/onefuse_admin')
    else:
        create_onefuse_setup_hook()
        content = (
            'Setup OneFuse?')
        action_url = reverse(
            'setup_onefuse')

        return {
            'title': 'Confirm OneFuse Setup',
            'content': content,
            'use_ajax': True,
            'action_url': action_url,
            'submit': 'Setup',
        }


def create_onefuse_setup_hook():
    onefuse_hook = {
        'name': "OneFuse CloudBolt Plugin Configuration",
        'description': ("Configure the OneFuse CloudBolt Plugin"),
        'hook_point': None,
        'module': '/var/opt/cloudbolt/proserv/xui/onefuse/configuration/setup.py',
    }
    create_hook(**onefuse_hook)
