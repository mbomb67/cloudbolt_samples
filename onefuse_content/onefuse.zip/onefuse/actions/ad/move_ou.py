if __name__ == "__main__":
    import os
    import sys
    import django

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
    sys.path.append("/opt/cloudbolt")
    sys.path.append("/var/opt/cloudbolt/proserv")
    django.setup()

import json
from common.methods import set_progress
from utilities.logger import ThreadLogger
from jobs.models import Job
from onefuse.cloudbolt_admin import CbOneFuseManager, Utilities


logger = ThreadLogger(__name__)


def run(job, *args, **kwargs):
    utilities = Utilities(logger)
    for server in job.server_set.all():
        logger.debug(f"Dictionary of keyword args passed to this "
                     f"plug-in: {kwargs.items()}")
        ad_state = server.get_cfv_for_custom_field("OneFuse_AD_State")
        logger.debug(f'object_json: {ad_state}')
        if ad_state and ad_state.value_as_string == 'build':
            object_json = server.get_cfv_for_custom_field("OneFuse_AD")
            if object_json:
                object_json = object_json.value_as_string
                mo = json.loads(object_json)
                onefuse_endpoint = mo["endpoint"]
                mo_name = mo["name"]
                mo_id = mo["id"]
                if onefuse_endpoint and mo_id:
                    logger.info(f"Starting OneFuse AD Move OU. Policy: "
                                f"{mo_name}, Endpoint: "
                                f"{onefuse_endpoint}, AD ID: {mo_id}")
                    from xui.onefuse.globals import VERIFY_CERTS
                    ofm = CbOneFuseManager(onefuse_endpoint, VERIFY_CERTS,
                                       logger=logger)
                    set_progress(f'Calling OneFuse to move Active Directory '
                                 f'OU for Managed Object. ID: {mo_id}')
                    response_json = ofm.move_ou(mo_id)
                    response_json["endpoint"] = onefuse_endpoint
                    state = response_json["state"]
                    utilities.check_or_create_cf("OneFuse_AD_State")
                    server.set_value_for_custom_field("OneFuse_AD_State", state)
                    utilities.check_or_create_cf("OneFuse_AD")
                    server.set_value_for_custom_field("OneFuse_AD",
                                                      json.dumps(response_json))
                    server.OneFuse_Tracking_Id = response_json["trackingId"]
                    server.save()
                    return_str = f"Move OU was successfully completed for " \
                                 f"{server.hostname}"
                    return "SUCCESS", return_str, ""
                else:
                    logger.info(f"OneFuse AD endpoint or ID was missing, "
                                f"Execution skipped")
                    return "SUCCESS", (f"No OneFuse AD object identified. AD "
                                       f"deletion skipped."), ""
            else:
                return "FAILURE", "", "OneFuse_AD not set unable to Move OU."
        else:
            logger.info(f"OneFuse AD state was either missing or not equal "
                        f"to 'Build', Execution skipped")
            return "SUCCESS", f"Move OU skipped.", ""


if __name__ == "__main__":
    job_id = sys.argv[1]
    j = Job.objects.get(id=job_id)
    run = run(j)
    if run[0] == "FAILURE":
        set_progress(run[1])