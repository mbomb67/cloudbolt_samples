"""
OneFuse Upstream Provider for CloudBolt

Enables the execution of OneFuse policies via CloudBolt Actions. Version 1.4 offers codeless integrations for Ansible Tower, BlueCat IPAM/DNS, InfoBlox IPAM/DNS, Men & Mice Micetro IPAM/DNS, SolarWinds IPAM, Microsoft DNS, Microsoft Active Directory, ServiceNow, Scripting, F5 and more. For more information, visit the <a href="https://onefuse.cloudbolt.io/">OneFuse Community Site</a>
"""

__version__ = "1.4.0"
__credits__ = 'Cloudbolt Software, Inc.'

# explicit list of extensions to be included instead of
# the default of .py and .html only
ALLOWED_XUI_EXTENSIONS = [".js", ".css", ".png", ".py", ".html", ".svg"]
