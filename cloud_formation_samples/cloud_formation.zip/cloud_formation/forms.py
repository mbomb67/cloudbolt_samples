from django import forms
from django.conf import settings
from django.core.files import File

from common.forms import C2Form
from common.widgets import SelectizeMultiple
from resources.models import ResourceType
from servicecatalog.models import ServiceBlueprint

from xui.cloud_formation.shared import (
    generate_options_for_cft_format,
    generate_options_for_connection_info,
    generate_options_for_resource_type,
    generate_options_for_allowed_environments,
    create_resource_type,
    create_generated_options_action,
    get_cft_from_source,
    add_blueprint_label,
    create_blueprint_level_params,
    add_bp_items,
    create_params,
)


class NewBlueprintForm(C2Form):
    def __init__(self, *args, **kwargs):
        super(NewBlueprintForm, self).__init__(*args, **kwargs)

        ci_choices = generate_options_for_connection_info()
        env_choices = generate_options_for_allowed_environments()
        rt_choices = generate_options_for_resource_type()

        self.fields["name"] = forms.CharField(max_length=50)
        self.fields["resource_type"] = forms.ChoiceField(
            label="Resource Type",
            choices=rt_choices,
        )
        self.fields["connection_info"] = forms.ChoiceField(
            label="Connection Info",
            choices=ci_choices,
            help_text="Connection Info for Git or AzureDevOps connection",
        )
        self.fields["cft_format"] = forms.ChoiceField(
            label="Template Format", choices=[("json", "JSON"), ("yaml", "YAML")]
        )
        self.fields["cft_url"] = forms.CharField(
            label="CloudFormation Template URL",
            help_text="URL to raw git file or s3 object",
        )
        self.fields["allowed_environments"] = forms.ModelMultipleChoiceField(
            queryset=env_choices, widget=SelectizeMultiple
        )

    def clean(self):
        envs = self.cleaned_data.get("allowed_environments")

        self.cleaned_data["allowed_environments"] = [str(env.id) for env in envs]

        return self.cleaned_data

    def save(self):
        ci_id = self.cleaned_data.get("connection_info")
        name = self.cleaned_data.get("name")
        cft_format = self.cleaned_data.get("cft_format")
        cft_url = self.cleaned_data.get("cft_url")
        allowed_envs = self.cleaned_data.get("allowed_environments")
        rt_id = self.cleaned_data.get('resource_type')

        template_json = get_cft_from_source(ci_id, cft_url)
        blueprint = ServiceBlueprint.objects.create(
            name=name, resource_type=ResourceType.objects.get(id=int(rt_id))
        )
        img = open(
            f"{settings.PROSERV_DIR}xui/cloud_formation/icons/cft_icon.png", "rb"
        )
        blueprint.list_image.save("new", File(img))
        img.close()

        create_blueprint_level_params(
            blueprint, template_json, cft_url, cft_format, allowed_envs, ci_id
        )
        add_blueprint_label(blueprint)
        add_bp_items(blueprint)

        aws_params_hook = create_generated_options_action(
            "Generate options for CF AWS Specific Params",
            "generate_options_for_aws_specific_params.py",
        )

        create_params(blueprint, template_json, cft_format, aws_params_hook)

        return blueprint
