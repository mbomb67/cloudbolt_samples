from django.conf.urls import url
from xui.cloud_formation import views

xui_urlpatterns = [
    url(
        r"^cloud_formation/create",
        views.create_cft_blueprint,
        name="cloudformation_create",
    ),
    url(
        r"^cloud_formation/(?P<blueprint_id>\d+)/edit/$",
        views.edit_cft_blueprint,
        name="edit_cft_blueprint",
    ),
    url(
        r"^cloud_formation/(?P<blueprint_id>\d+)/delete/$",
        views.delete_cft_blueprint,
        name="delete_cft_blueprint",
    ),
    # url(
    #     r"^arm_templates/(?P<blueprint_id>\d+)/sync/$",
    #     views.sync_cft_blueprint,
    #     name="sync_cft_blueprint",
    # ),
]
