"""
Methods for the CloudFormation XUI that need to be used in different actions
are stored in this module.
"""
import json

import requests
import urllib
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Q

from cbhooks.models import CloudBoltHook, HookPoint, HookPointAction, OrchestrationHook
from common.methods import set_progress
from infrastructure.models import Environment, CustomField, FieldDependency, Namespace
from orders.models import CustomFieldValue
from resources.models import ResourceType
from servicecatalog.models import RunCloudBoltHookServiceItem, TearDownServiceItem
from tags.models import CloudBoltTag
from utilities.exceptions import CloudBoltException
from utilities.logger import ThreadLogger
from utilities.models import ConnectionInfo
from utilities.run_command import execute_command

logger = ThreadLogger(__name__)


def get_conn_info_type(conn_info):
    try:
        conn_info.labels.get(name="github")
        conn_info_type = "github"
    except ObjectDoesNotExist:
        try:
            conn_info.labels.get(name="gitlab")
            conn_info_type = "gitlab"
        except ObjectDoesNotExist:
            raise CloudBoltException(
                f"Github or Gitlab label not found on {conn_info} Connection."
            )
    logger.debug(
        f"Connection info: {conn_info.name} determined to be type of "
        f"{conn_info_type}"
    )
    return conn_info_type


def generate_options_for_resource_type():
    rts = ResourceType.objects.all()
    options = [(rt.id, rt.label) for rt in rts]

    return options


def generate_options_for_cft_format(server=None, **kwargs):
    options = [("json", "JSON"), ("yaml", "YAML")]
    return options


def generate_options_for_connection_info(server=None, **kwargs):
    cis = ConnectionInfo.objects.filter(
        Q(labels__name="github") | Q(labels__name="gitlab")
    )

    options = [(0, "Public Repository")]

    for ci in cis:
        if ci.name == "CloudBolt Content Library":
            continue
        ci_type = get_conn_info_type(ci)
        options.append((ci.id, f"{ci.name}: {ci_type}"))
    return options


def generate_options_for_allowed_environments(server=None, **kwargs):
    envs = Environment.objects.filter(
        resource_handler__resource_technology__modulename__contains="aws"
    )
    return envs


def create_param_name(param_prefix, bp_id):
    return f"{param_prefix}_{bp_id}"


def create_custom_field_option(blueprint, value, field, cf_type):
    """
    Create a CustomFieldValue for a Custom Field, then add that value to the
    Blueprint level Parameter. This will check first to see if the value
    already exists for that parameter on the blueprint, and if so, not re-add
    to the Blueprint
    """
    logger.debug(
        f"Creating Parameter: {field.name} option, type: {cf_type}," f" Value: {value}"
    )
    if cf_type == "STR":
        cfv = CustomFieldValue.objects.get_or_create(str_value=value,
                                                     field=field)[0]
    elif cf_type == "INT":
        cfv = CustomFieldValue.objects.get_or_create(int_value=value,
                                                     field=field)[0]
    elif cf_type == "BOOL":
        cfv = CustomFieldValue.objects.get_or_create(boolean_value=value,
                                                     field=field)[0]
    elif cf_type == "CODE":
        cfv = CustomFieldValue.objects.get_or_create(txt_value=value,
                                                     field=field)[0]
    else:
        logger.warn(
            f"Unknown Parameter type: {cf_type}, passed in, not "
            f"creating custom field option for field: {field}"
        )
        return None
    cfvs = blueprint.get_cfvs_for_custom_field(field.name)
    if cfv not in cfvs:
        # Don't want to re-add a value if it already exists on the BP
        blueprint.custom_field_options.add(cfv.id)
    return cfv


def add_cfvs_for_field(blueprint, cf, cf_type, new_values: list):
    """
    Add new values to the blueprint for a field, remove CFVs that are not in
    new_values
    """
    existing_cfvs = blueprint.custom_field_options.filter(field__id=cf.id)
    new_cfvs = []
    for value in new_values:
        cfv = create_custom_field_option(blueprint, value, cf, cf_type)
        if cfv:
            new_cfvs.append(cfv)
    remove_old_cfvs(blueprint, existing_cfvs, new_cfvs)


def remove_old_cfvs(blueprint, existing_cfvs, new_cfvs):
    for cfv in existing_cfvs:
        if cfv not in new_cfvs:
            logger.debug(f'Removing CustomFieldValue: {cfv} from options')
            blueprint.custom_field_options.remove(cfv)



def create_cf(
    cf_name,
    cf_label,
    description,
    cf_type="STR",
    allow_multiple=False,
    required=True,
    **kwargs,
):
    namespace, _ = Namespace.objects.get_or_create(name="aws_cloudformation")

    # You can pass in show_on_servers, show_as_attribute as kwargs
    defaults = {
        "label": cf_label,
        "description": description,
        "required": required,
        "allow_multiple": allow_multiple,
        "namespace": namespace,
    }
    for key, value in kwargs.items():
        defaults[key] = value

    cf = CustomField.objects.get_or_create(
        name=cf_name, type=cf_type, defaults=defaults
    )
    return cf


def create_cloudbolt_hook(new_action_name, source_file):
    root_dir = "/var/opt/cloudbolt/proserv/xui/cloud_formation/actions/"
    hook, hook_created = CloudBoltHook.objects.get_or_create(
        name=new_action_name, source_code_url=f"file://{root_dir}{source_file}"
    )
    hook.get_runtime_module()
    hook.description = "Used for CloudFormation Builder"
    hook.shared = True
    hook.save()
    if hook_created:
        set_progress(f"CloudBolt Hook created: {new_action_name}")
    else:
        set_progress(f"CloudBolt Hook retrieved: {new_action_name}")
    return hook


def create_generated_options_action(new_action_name, source_file):
    # Create Action (CloudBoltHook)
    hook = create_cloudbolt_hook(new_action_name, source_file)

    # Create HookPointAction
    hp_id = HookPoint.objects.get(name="generated_custom_field_options").id
    hpa = HookPointAction.objects.get_or_create(
        name=new_action_name, hook=hook, hook_point_id=hp_id
    )[0]
    hpa.enabled = True
    hpa.continue_on_failure = False
    hpa.save()

    oh = OrchestrationHook.objects.get_or_create(
        name=new_action_name, cloudbolthook=hook
    )[0]
    oh.hookpointaction_set.add(hpa)
    oh.save()

    return oh


def create_param_label(param):
    # RobF this likely needs to change, depending on the format of CFT params
    param_label = " ".join(camel_case_split(param)).title()
    # Handles QuickStart templates where underscores are used
    param_label = param_label.replace("_", " ")
    return param_label


def camel_case_split(str):
    words = [[str[0]]]
    for c in str[1:]:
        if words[-1][-1].islower() and c.isupper():
            words.append(list(c))
        else:
            words[-1].append(c)
    return ["".join(word) for word in words]


def get_cft_from_source(connection_info_id, cft_url):
    if int(connection_info_id) != 0:
        conn_info = ConnectionInfo.objects.get(id=connection_info_id)
        conn_info_type = get_conn_info_type(conn_info)
    else:
        conn_info_type = 'public'

    if conn_info_type == "gitlab":
        cft = get_template_from_gitlab(conn_info, cft_url)
    elif conn_info_type == "github":
        cft = get_template_from_github(conn_info, cft_url)
    elif conn_info_type == 'public':
        cft = get_public_template(cft_url)
    else:
        raise Exception(f"Connection Info type not recognized: " f"{conn_info_type}")
    return cft


def get_public_template(url):
    if url.find('raw') == -1:
        raise CloudBoltException(f'URL entered was not in raw format, please '
                                 f're-submit request using a raw formatted '
                                 f'URL')
    response = requests.get(url)
    response.raise_for_status()
    return response.content.decode("utf-8")


def get_template_from_github(conn_info, cft_url):
    # Will read a github
    import base64

    url_split = cft_url.split("/")
    username = url_split[3]
    repo = url_split[4]
    if cft_url.startswith("https://github.com"):
        branch = url_split[6]
    else:
        branch = url_split[5]
    file_path = cft_url.split(f"/{branch}/")[1].split("?")[0]

    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"token {conn_info.password}",
    }
    git_url = (
        f"https://api.github.com/repos/{username}/{repo}/contents/"
        f"{file_path}?ref={branch}"
    )
    response = requests.get(git_url, headers=headers)
    response.raise_for_status()
    data = response.json()
    content = data["content"]
    file_content_encoding = data.get("encoding")
    if file_content_encoding == "base64":
        content = base64.b64decode(content).decode()
    return content


def get_template_from_gitlab(conn_info, cft_url):
    # For gitlab, it doesn't matter if the URL passed is the Raw or the normal
    # URL. The URL needs to be reconstructed to make an API call. The token
    # created for auth will need at a minimum read_api and read_repository
    base_url = f"https://{cft_url.split('/')[2]}:443/api/v4"
    project_path = "/".join(cft_url.split("/-/")[0].split("/")[-2:])
    project_id = urllib.parse.quote(project_path, safe="")
    url_split = cft_url.split("/-/")[1].split("/")
    branch = url_split[1]
    file_path = urllib.parse.quote("/".join(url_split[2:]), safe="")
    path = f"/projects/{project_id}/repository/files/{file_path}/raw" f"?ref={branch}"
    set_progress(f"Submitting request to GitLab URL: {path}")
    headers = {
        "PRIVATE-TOKEN": conn_info.password,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    request_url = f"{base_url}{path}"
    r = requests.get(request_url, auth=None, headers=headers)
    r.raise_for_status()
    r_json = r.json()
    raw_file_json = json.dumps(r_json)
    return raw_file_json


def add_blueprint_label(blueprint):
    # Create Label if it doesn't exist
    label = CloudBoltTag.objects.get_or_create(
        name="CloudFormation", model_name="serviceblueprint"
    )[0]
    # Add Label to Blueprint
    blueprint.tags.add(label)
    return None


def create_cf_bp_options(
    cf_name,
    cf_label,
    description,
    blueprint,
    values: list,
    cf_type="STR",
    allow_multiple=False,
    required=True,
    **kwargs,
):
    # Create the Custom Field
    cf = create_cf(
        cf_name, cf_label, description, cf_type, allow_multiple, required, **kwargs
    )[0]

    # Add it to the Blueprint
    blueprint.custom_fields_for_resource.add(cf)

    add_cfvs_for_field(blueprint, cf, cf_type, values)
    return cf


def create_blueprint_level_params(
    blueprint, template_json, cft_url, allowed_environments, conn_info_id
):
    # Save Cloud Formation Template
    create_cf_bp_options(
        "cloud_formation_template",
        "CloudFormation Template",
        "CloudFormation Template Contents",
        blueprint,
        [template_json],
        cf_type="CODE",
        single_value=True,
    )

    # Save Allowed Environments
    env_ids = ",".join(allowed_environments)
    allowed_envs_cf = create_cf_bp_options(
        "cft_allowed_env_ids",
        "Allowed Environments",
        "A list of the IDs of Environments allowed for the " "CFT",
        blueprint,
        [env_ids],
        single_value=True,
    )

    # Save CFT URL
    create_cf_bp_options(
        "cft_url",
        "CloudFormation URL",
        "The URL where the CFT is located in Source Control",
        blueprint,
        [cft_url],
        single_value=True,
    )

    # Save Connection Info ID
    create_cf_bp_options(
        "cft_conn_info_id",
        "ConnectionInfo ID",
        "The ID of the Connection Info for Source Control",
        blueprint,
        [conn_info_id],
        single_value=True,
    )

    # Create CloudFormation Stack Name param
    create_cf_bp_options(
        "cft_stack_name",
        "CloudFormation Stack Name",
        "Name of the CloudFormation Stack",
        blueprint,
        [],
        show_on_servers=True,
    )

    # Create Environment Parameter, add to Blueprint
    env_cf = create_cf_bp_options(
        "cft_env_id", "Environment", "AWS Environment", blueprint, []
    )

    # Create Programmatically Gen Options action for environment
    oh = create_generated_options_action(
        "Generate options for 'cft_env_id'", "generate_options_for_env_id.py"
    )
    env_cf.orchestration_hooks.add(oh)
    env_cf.save()
    blueprint.custom_fields_for_resource.add(env_cf)

    # Create Field Dependency for Environment to read from list of allowed envs
    create_field_dependency(allowed_envs_cf, env_cf)

    # Create CloudFormation Stack Name param
    options = ["DO_NOTHING", "ROLLBACK", "DELETE"]
    create_cf_bp_options(
        "cft_fail_behavior",
        "CloudFormation Failure Behavior",
        "Failure Behavior for CloudFormation Stack Deployment",
        blueprint,
        options,
    )

    # Create CloudFormation Capabilities dropdown
    options = ["CAPABILITY_IAM", "CAPABILITY_NAMED_IAM", "CAPABILITY_AUTO_EXPAND"]
    create_cf_bp_options(
        "cft_capabilities",
        "CloudFormation Capabilities",
        (
            "In some cases, you must explicitly acknowledge that your stack "
            "template contains certain capabilities in order for CloudFormation "
            "to create the stack."
        ),
        blueprint,
        options,
        allow_multiple=True,
        required=False,
        show_on_servers=True,
    )


def create_field_dependency(
    control_field, dependent_field, dependency_type: str = "REGENOPTIONS"
):
    dependency, _ = FieldDependency.objects.get_or_create(
        controlling_field=control_field,
        dependent_field=dependent_field,
        dependency_type=dependency_type,
    )
    return dependency


def add_bp_items(blueprint):
    # Add Build Item
    hook = create_cloudbolt_hook("Cloud Formation Build", "deploy_cft.py")
    oh, _ = OrchestrationHook.objects.get_or_create(
        name="Cloud Formation Build", cloudbolthook=hook
    )
    rcbhsi, _ = RunCloudBoltHookServiceItem.objects.get_or_create(
        name="Cloud Formation Build",
        hook=oh,
        blueprint=blueprint,
        show_on_order_form=False,
        run_on_scale_up=False,
    )

    # Add Teardown Item
    hook = create_cloudbolt_hook("Cloud Formation Teardown", "teardown_cft.py")
    oh, _ = OrchestrationHook.objects.get_or_create(
        name="Cloud Formation Teardown", cloudbolthook=hook
    )
    tdsi, _ = TearDownServiceItem.objects.get_or_create(
        name="Cloud Formation Teardown", hook=oh, blueprint=blueprint, deploy_seq=-1
    )


def create_params(blueprint, template_json, aws_params_hook=None):
    # import cfn_tools. If it's not installed, install it and import it.
    bp_id = blueprint.id
    template_content = ""

    try:
        json.loads(template_json)
    except json.decoder.JSONDecodeError:
        try:
            import cfn_tools
        except ImportError or ModuleNotFoundError:
            set_progress("Installing CFN Tools")
            execute_command("pip install cfn_flip")
            import cfn_tools
        try:
            temp_data = cfn_tools.load_yaml(template_json)
            template_content = json.loads(
                json.dumps(temp_data)
            )  # converts the OrderedDict output by cfn-tools into a standard dict
        except:
            set_progress("Could not Parse template, verify it is valid Yaml or JSON.")

    template_params = template_content.get("Parameters", None)
    if template_params:
        param_prefix = f"cft_{bp_id}_"
        for key in template_params.keys():
            create_param(key, template_params, param_prefix, blueprint, aws_params_hook)


def create_param(key, template_params, param_prefix, blueprint,
                 aws_params_hook=None):
    param = template_params[key]
    param_type = param["Type"]
    new_param_name = f"{param_prefix}{key}"
    param_label = create_param_label(key)
    description = param.get("Description", "CloudFormation Builder Param")

    if param.get('NoEcho'):
        cf, cf_created = create_cf(new_param_name, param_label, description, 'PWD')
        # Do not want to set a value for passwords, just continue to next param
        logger.debug(f'Created Param: {new_param_name}, type: {type}, '
                     f'label: {param_label}')
        blueprint.custom_fields_for_resource.add(cf)
        # We don't want any dropdown values for a PWD field. This call will
        # strip any cfvs from the field
        add_cfvs_for_field(blueprint, cf, 'PWD', [])
        return

    # TODO handle constraints

    allow_multiple = False
    required = True
    if param_type == "String":
        cf_type = "STR"
    elif param_type == "Number":
        cf_type = "INT"
    elif param_type == "List<Number>":
        cf_type = "INT"
        allow_multiple = True
    elif param_type == "CommaDelimitedList":
        cf_type = "STR"
        allow_multiple = True
    elif param_type.startswith("AWS::"):
        cf_type = "STR"
        new_param_name = new_param_name + "_" + param_type.replace("::", "_")
        required = False

    else:
        logger.warn(
            f"Unable to find a known type for parameter: {key}."
            f"This parameter will not be considered in the created"
            f"blueprint"
        )
        return
    allowed_values = param.get("AllowedValues", None)
    # Create the parameter
    logger.debug(
        f"Creating Parameter: {new_param_name}, type: {type}, " f"label: {param_label}"
    )
    cf, cf_created = create_cf(
        new_param_name,
        param_label,
        description,
        cf_type,
        allow_multiple,
        required,
        show_on_servers=True,
    )

    if param_type.startswith("AWS::"):
        cf.orchestration_hooks.add(aws_params_hook)
        env_field = CustomField.objects.get(name="cft_env_id")
        logger.debug(f"Env Field name {env_field.name}")
        dep = create_field_dependency(env_field, cf)
        logger.debug(f"Field Dep {dep.id}, {dep}")
        cf.save()

    # Add it to the Blueprint
    blueprint.custom_fields_for_resource.add(cf)

    # Create Add value from parameters file as selection in dropdown
    # If a list of allowed values exists, then we want to create a dropdown
    # with those values. If allowed values are not set, check the params
    # file for a value and then the template itself for a default value
    # to set a single value for the parameter options
    if allowed_values:
        add_cfvs_for_field(blueprint, cf, cf_type, allowed_values)
    else:
        default_value = template_params[key].get("Default", None)
        if default_value:
            add_cfvs_for_field(blueprint, cf, cf_type, [default_value])


def create_resource_type(type_name, **kwargs):
    defaults = {}
    for key, value in kwargs.items():
        defaults[key] = value
    resource_type, _ = ResourceType.objects.get_or_create(
        name=type_name, defaults=defaults
    )
    return resource_type
