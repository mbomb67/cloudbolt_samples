from django.contrib import messages
from django.db.models import Q
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django.utils.html import format_html
from django.utils.translation import ugettext as _

from cbhooks.models import CloudBoltHook
from extensions.views import admin_extension
from infrastructure.models import Environment, CustomField
from orders.models import CustomFieldValue
from resources.models import Resource
from servicecatalog.models import ServiceBlueprint
from tabs.views import TabGroup
from tags.models import CloudBoltTag
from utilities.decorators import dialog_view
from utilities.models import ConnectionInfo
from utilities.templatetags import helper_tags
from xui.cloud_formation.shared import (
    get_conn_info_type,
    get_cft_from_source,
    delete_cfvs_for_field,
)
from xui.cloud_formation.forms import NewBlueprintForm


def get_docstring():
    return """
The OneFuse XUI for CloudBolt allows for the execution of OneFuse Codeless 
Integrations during the lifecycle of a CloudBolt Blueprint. This XUI relies
on the OneFuse Python Plugin (https://pypi.org/project/onefuse/) which will 
be installed during the setup step.

Installation Instructions:
1. Install the XUI in CloudBolt. The onefuse directory should end up at:
    /var/opt/cloudbolt/proserv/xui/onefuse
2. Restart Apache
    > systemctl restart httpd
2. Create a Connection Info for onefuse. This must be labelled as 'onefuse'
3. Execute the Configuration script.
    > python /var/opt/cloudbolt/proserv/xui/onefuse/configuration/setup.py

OneFuse Parameter usage ('name' : 'value_format'):
    'OneFuse_AnsibleTowerPolicy_<executionstring>_<uniqueName>' : '<onefusehost>:<policyname>:<hosts>:<limit>'
    'OneFuse_DnsPolicy_Nic<#>' : '<onefusehost>:<policyname>:<dnszones>'
    'OneFuse_IpamPolicy_Nic<#>' : '<onefusehost>:<policyname>'
    'OneFuse_ADPolicy' : '<onefusehost>:<policyname>'
    'OneFuse_NamingPolicy' : '<onefusehost>:<policyname>'
    Property Toolkit properties:
        'OneFuse_PropertyToolkit' : '<onefusehost>:true'
        'OneFuse_SPS_<uniqueName>' : '<staticpropertysetname>'
        'OneFuse_CreateProperties_<uniqueName>' : '{"key":"<key>","value":"<value>"}'
    'OneFuse_ScriptingPolicy_<executionstring>_<uniqueName>' : '<onefusehost>:<policyname>'
    'OneFuse_ServiceNowCmdbPolicy_<executionstring>_<uniqueName>' : '<onefusehost>:<policyname>'
    'OneFuse_PluggableModulePolicy_<executionstring>_<uniqueName>' : '<onefusehost>:<policyname>'

    Valid Execution Strings for Ansible Tower and Scripting:
        HostnameOverwrite
        PreCreateResource
        PreApplication (only valid when configuration manager used)
        PostProvision

"""


@dialog_view()
def create_cft_blueprint(request):
    action_url = reverse("cloudformation_create")

    if request.method == "POST":
        form = NewBlueprintForm(request.POST)
        if form.is_valid():
            blueprint = form.save()
            msg = f"New CloudFormation Blueprint Created: {blueprint.name}"
            messages.success(request, msg)
            return HttpResponseRedirect(request.META["HTTP_REFERER"])
    else:
        form = NewBlueprintForm()

    return {
        "title": "Add CloudFormation Template Blueprint",
        "form": form,
        "use_ajax": True,
        "action_url": action_url,
        "submit": "Save",
    }


@dialog_view()
def edit_cft_blueprint(request, blueprint_id):
    blueprint = ServiceBlueprint.objects.get(id=blueprint_id)
    action_url = reverse('edit_cft_blueprint', args=[blueprint_id])

    if request.method == 'POST':
        form = NewBlueprintForm(request.POST)
        if form.is_valid():
            form.save()
            msg = f"CloudFormation Blueprint ({blueprint.name}) has been updated."
            messages.success(request, msg)
            return HttpResponseRedirect(request.META["HTTP_REFERER"])
    else:
        env_ids = [int(i) for i in blueprint.cft_allowed_env_ids.split(',')]
        initial_envs = Environment.objects.filter(id__in=env_ids)

        ci = ConnectionInfo.objects.get(id=blueprint.cft_conn_info_id)
        form = NewBlueprintForm(initial={
            'name': blueprint.name,
            'allowed_environments': initial_envs,
            'cft_url': blueprint.cft_url,
            'cft_format': blueprint.cft_format,
            'conn_info_id': (ci.id, f"{ci.name}: {get_conn_info_type(ci)}"),
            'resource_type': (blueprint.resource_type.id, blueprint.resource_type.label),
        })

    return {
        "title": "Edit CloudFormation Template Blueprint",
        "form": form,
        "use_ajax": True,
        "action_url": action_url,
        "submit": "Save",
    }


@dialog_view
def delete_cft_blueprint(request, blueprint_id):
    if request.method == 'POST':
        blueprint = ServiceBlueprint.objects.get(id=blueprint_id)
        bp_cfs = CustomField.objects.filter(name__startswith=f"cft_{blueprint.id}_")
        for cf in bp_cfs:
            for cfv in cf.customfieldvalue_set.all():
                cfv.delete()
            for cfm in cf.customfieldmapping_set.all():
                cfm.delete()
            for cfr in cf.customfieldrate_set.all():
                cfr.delete()

            cf.delete()

        # Delete the Resource Type if there are no active Resources and no active Blueprints using it.
        resource_type = blueprint.resource_type
        if not Resource.objects.filter(resource_type=resource_type, status='ACTIVE'):
            if not resource_type.serviceblueprint_set.filter(status='ACTIVE').exclude(id=blueprint_id):
                resource_type.delete()

        blueprint.delete()
        msg = "The CloudFormation Blueprint has been removed."
        messages.success(request, msg)
        return HttpResponseRedirect(request.META['HTTP_REFERER'])

    return {
        'title': 'Remove CloudFormation Blueprint?',
        'content': 'Are you sure you want to delete this CloudFormation Blueprint?',
        'use_ajax': True,
        'action_url': reverse('delete_cft_blueprint', args=[blueprint_id]),
        'submit': 'Remove'
    }


def get_cft_connection_infos():
    tags = CloudBoltTag.objects.filter(
        Q(name="github", model_name="connectioninfo")
        | Q(name="s3", model_name="connectioninfo")
    )
    connection_infos = []
    for tag in tags:
        conn_infos = ConnectionInfo.objects.filter(labels=tag)
        for conn_info in conn_infos:
            connection_infos.append(conn_info)
    return connection_infos


def get_cft_blueprints():
    tags = CloudBoltTag.objects.filter(
        name="CloudFormation", model_name="serviceblueprint"
    )
    cfts = []
    for tag in tags:
        bps = ServiceBlueprint.objects.filter(tags=tag, status="ACTIVE")
        for bp in bps:
            bp_dict = {}
            bp_dict["bp"] = bp
            conn_info = ConnectionInfo.objects.get(id=bp.cft_conn_info_id)
            bp_dict["conn_info"] = conn_info
            bp_dict["conn_info_type"] = get_conn_info_type(conn_info)
            bp_dict["url"] = bp.cft_url
            bp_dict["filename"] = bp.cft_url.split("/")[-1:][0]
            allowed_envs = [env.strip() for env in bp.cft_allowed_env_ids.split(",")]
            bp_dict["allowed_envs"] = []
            for env in allowed_envs:
                env = Environment.objects.get(id=env)
                bp_dict["allowed_envs"].append(env)
            cfts.append(bp_dict)
    return cfts


def get_environment_from_resource(resource):
    env = Environment.objects.get(id=resource.cft_env_id)
    return env


def get_params_from_resource(resource):
    cfv_dict = resource.get_cf_values_as_dict()
    pfx = f"cft_{resource.blueprint_id}_"
    otp = f"{pfx}output_"
    return {
        get_cf_label(k): v
        for k, v in cfv_dict.items()
        if k.startswith(pfx) and not k.startswith(otp)
    }


def get_cf_label(cf_name):
    return CustomField.objects.get(name=cf_name).label


def get_outputs_from_resource(resource):
    cfv_dict = resource.get_cf_values_as_dict()
    pfx = f"cft_{resource.blueprint_id}_output_"
    return {get_cf_label(k): v for k, v in cfv_dict.items() if k.startswith(pfx)}


def get_cft_resources():
    # Get resources with resource type cf_stack and lifecycle != HISTORICAL
    cft_resources = []
    resources = Resource.objects.filter(
        Q(resource_type__name="cf_stack"), ~Q(lifecycle="HISTORICAL")
    )
    for resource in resources:
        cft_resource = {
            "stack": resource,
            "environment": get_environment_from_resource(resource),
            "parameters": get_params_from_resource(resource),
            "outputs": get_outputs_from_resource(resource),
        }
        cft_resources.append(cft_resource)
    return cft_resources


@admin_extension(
    title="Cloud Formation Library", description="CloudFormation library for CloudBolt."
)
def library(request, **kwargs):
    context = {
        "connection_infos": get_cft_connection_infos(),
        "cfts": get_cft_blueprints(),
        "resources": get_cft_resources(),
    }

    admin_context = {
        "tabs": TabGroup(
            template_dir="cloud_formation/templates",
            context=context,
            request=request,
            tabs=[
                # First tab uses template 'groups/tabs/tab-main.html'
                # (_("Configuration"), 'configuration', {}),
                # Tab 2 is conditionally-shown in this slot and
                # uses template 'groups/tabs/tab-related-items.html'
                (_("Blueprints"), "blueprints", {}),
                (_("Deployed Stacks"), "stacks", {}),
                (_("Source Control"), "sourcecontrol", {}),
            ],
        )
    }

    return render(
        request, "cloud_formation/templates/admin.html", context=admin_context
    )


# @dialog_view
# def sync_cft_blueprint(request, cft_id):
#     """
#     View for synchronizing CB Blueprint with CFT. The latest CFT version is
#     always pulled at execution, BUT parameters are not updated there, this
#     allows for the updating of parameters.
#     """
#     blueprint = ServiceBlueprint.objects.get(id=cft_id)
#
#     # Get the latest version of the CFT from Source Code Repo
#     conn_info_id = blueprint.cft_conn_info_id
#     cft_url = blueprint.cft_url
#     template_json = get_cft_from_source(conn_info_id, cft_url)
#
#     # First Delete existing option(s) for the CFT
#     delete_cfvs_for_field(blueprint, "cloud_formation_template")
#
#     # Add the new CFT value to the Blueprint
#     cfv = CustomFieldValue.objects.get_or_create(
#         txt_value=template_json, field="cloud_formation_template"
#     )[0]
#     blueprint.custom_field_options.add(cfv.id)
#
#     if request.method == 'POST':
#         hook = CloudBoltHook.objects.get(name="OneFuse CloudBolt Plugin "
#                                               "Configuration")
#         job = hook.run_as_job()[0]
#         msg = format_html(
#             _("Job {job_name} has been created to check rule(s).").format(
#                 job_name=helper_tags.render_simple_link(job)
#             )
#         )
#
#         messages.info(request, msg)
#         return HttpResponseRedirect('/onefuse_admin')
#     else:
#         create_onefuse_setup_hook()
#         content = (
#             'Setup OneFuse?')
#         action_url = reverse(
#             'setup_onefuse')
#
#         return {
#             'title': 'Confirm OneFuse Setup',
#             'content': content,
#             'use_ajax': True,
#             'action_url': action_url,
#             'submit': 'Setup',
#         }
#
#
#
