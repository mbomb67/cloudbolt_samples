"""
Teardown Service Item Action for ARM Template Blueprint

This action was created by the ARM Builder Blueprint

Do not edit this script directly as all resources provisioned by the ARM
Builder Blueprint use this script. If you need to make one-off modifications,
copy this script and create a new action leveraged by the blueprint that needs
the modifications.
"""

if __name__ == "__main__":
    import django

    django.setup()

from resourcehandlers.aws.models import AWSHandler
from common.methods import set_progress
from utilities.logger import ThreadLogger
from infrastructure.models import Environment

logger = ThreadLogger(__name__)


def run(job, *args, **kwargs):
    resource = job.resource_set.first()
    if resource:
        set_progress(f"Teardown CFT plugin running for resource: {resource}")
        try:
            cft_env_id = resource.cft_env_id
            if cft_env_id is None:
                raise Exception(f"Environment ID not found.")
        except:
            msg = "No Environment ID set on the blueprint, exiting"
            set_progress(msg)
            return "ERROR", "", msg
        try:
            cft_stack_name = resource.cft_stack_name
            if cft_stack_name is None:
                raise Exception(f"CloudFormation Stack Name not found.")
        except:
            msg = "No CloudFormation Stack Name set on the blueprint, " "continuing"
            set_progress(msg)
            return "SUCCESS", msg, ""

        env = Environment.objects.get(id=cft_env_id)

        # Instantiate AWS Resource Client
        rh: AWSHandler = env.resource_handler.cast()
        wrapper = rh.get_api_wrapper()
        region = env.aws_region

        # Delete Resources
        attempts = 0
        try:
            set_progress(
                f"Deleting AWS CloudFormation Stack with Name: " f"{cft_stack_name}"
            )
            client = wrapper.get_boto3_client(
                "cloudformation", rh.serviceaccount, rh.servicepasswd, region
            )
            set_progress(f'Deleting CloudFormation stack "{cft_stack_name}"')
            response = client.delete_stack(StackName=cft_stack_name)
        except:
            set_progress("CloudFormation Stack deletion failed.")
            return "FAILURE", "", ""

        # Delete CB Server Records. This action has already deleted the Virtual
        # Machines themselves
        for server in resource.server_set.all():
            set_progress(f"Deleting CB Server record for: {server.hostname}")
            server.delete()
        return "SUCCESS", "All resources successfully deleted", ""

    else:
        set_progress("Resource was not found")
        return "SUCCESS", "Resource was not found", ""


if __name__ == "__main__":
    run()
