"""
Build service item action for AWS CloudFormation(CF) Templates deployment.

This action was created by the AWS CloudFormation UI Extension.

Do not edit this script directly as all resources provisioned by the AWS
CFT Builder Blueprint use this script. If you need to make one-off changes,
copy this script and create a new action leveraged by the blueprint that needs
the modifications.
"""
import time

from resources.models import Resource
from utilities.exceptions import NotFoundException

if __name__ == "__main__":
    import os
    import sys
    import django

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
    sys.path.append("/opt/cloudbolt")
    sys.path.append("/var/opt/cloudbolt/proserv")
    django.setup()

from jobs.models import Job
from utilities.events import add_server_event
from common.methods import set_progress
from infrastructure.models import CustomField, Server
from infrastructure.models import Environment
from utilities.logger import ThreadLogger
from xui.cloud_formation.shared import create_cf, get_cft_from_source

logger = ThreadLogger(__name__)


#################
def create_field_set_value(field_name, label, value, description, resource):
    create_cf(field_name, label, description, show_on_servers=True)
    resource.set_value_for_custom_field(field_name, value)
    return resource


def run(job, **kwargs):
    resource = kwargs.get("resource")
    if not resource:
        msg = f"CloudBolt Resource object not found."
        set_progress(msg)
        return "FAILURE", msg, ""
    set_progress(
        f"Starting deploy of CloudFormation Template for resource: " f"{resource}"
    )
    cft, stack_name = get_high_level_parameters(resource)
    save_cft_to_resource(resource, cft)
    env = Environment.objects.get(id=resource.cft_env_id)
    rh = env.resource_handler.cast()
    cft_prefix = f"cft_{resource.blueprint_id}_"
    parameters = fetch_parameters_for_cft_deployment(resource, cft_prefix)
    client = rh.get_boto3_client(
        region_name=env.aws_region, service_name="cloudformation"
    )
    try:
        stack = submit_template_request(stack_name, cft, parameters, resource, client)
        update_cb_resource(resource, stack, env, job, client, cft_prefix)
        return "SUCCESS", "CloudFormation Template deployment complete", ""
    except Exception as err:
        msg = f'CloudFormation Template deployment failed: {err}'
        return "FAILURE", "", msg


def get_high_level_parameters(resource):
    stack_name = resource.get_cfv_for_custom_field("cft_stack_name").value
    try:
        cft_url = resource.get_cfv_for_custom_field("cft_url").value
        conn_info_id = resource.get_cfv_for_custom_field("cft_conn_info_id").value
        cft = get_cft_from_source(conn_info_id, cft_url)
        logger.info(
            f"Successfully connected to source control to get latest "
            f"version of Cloud Formation Template"
        )
    except:
        logger.warn(
            f"Unable to connect to source control to get latest "
            f"version. Using original CFT."
        )
        cft = resource.get_cfv_for_custom_field("cloud_formation_template").value
    return cft, stack_name


def fetch_parameters_for_cft_deployment(resource, cft_prefix):
    """
    Get & return the parameters to pass to the AWS job to deploy the CF
    template.
    These are the parameters that are defined in the CF template itself as
    inputs for the CF template deployment.
    Look for these parameters on the Resource object, where the deploy BP job
    in CB created them.
    """
    parameters = []
    cfvs = resource.get_cf_values_as_dict()
    for key in cfvs.keys():
        if key.find(cft_prefix) == 0:
            param_key = key.replace(cft_prefix, "")
            param_key = replace_cft_types_in_key(param_key)
            value = cfvs[key]
            parameters.append({"ParameterKey": param_key, "ParameterValue": value})
            cf = CustomField.objects.get(name=key)
            if cf.type == "PWD":
                logger.debug(f"Setting password: {param_key} to: ******")
            else:
                logger.debug(f"Setting param: {param_key} to: {value}")
    return parameters


def replace_cft_types_in_key(param_key):
    # Replace known cft types in the param_key leaving just the parameter name
    param_key = param_key.replace("_AWS_EC2_Subnet_Id", "")
    param_key = param_key.replace("_AWS_EC2_InstanceType_Name", "")
    param_key = param_key.replace("_AWS_EC2_Image_Id", "")
    param_key = param_key.replace("_AWS_EC2_AvailabilityZone_Name", "")
    return param_key

def submit_template_request(stack_name, cft, parameters, resource, client):
    """
    return stack dict if successful; raises exception on failure
    """
    timeout = 900
    logger.debug(
        f"Submitting request for CloudFormation template. stack_name:"
        f" {stack_name} template: {cft}"
    )
    set_progress(
        f"Submitting CloudFormation request to AWS. This can take a "
        f"while. Timeout is set to: {timeout}"
    )

    try:
        set_progress(f'Creating stack "{stack_name}"')
        capabilities = resource.cft_capabilities
        if not capabilities:
            capabilities = []
        response = client.create_stack(
            StackName=stack_name,
            TemplateBody=cft,
            Parameters=parameters,
            TimeoutInMinutes=timeout,
            OnFailure=resource.cft_fail_behavior,
            Capabilities=capabilities,
        )
        stack_id = response["StackId"]
        set_progress(f'Created StackId: {stack_id}')
        stack = wait_for_stack_completion(client, stack_id)
        return stack
    except Exception as err:
        set_progress("Stack creation was not successful")
        raise err


def wait_for_stack_completion(client, stack_name):
    response = client.describe_stacks(StackName=stack_name)
    stack = response["Stacks"][0]
    # wait for stack to be created. Check status every minutes
    while stack["StackStatus"] == "CREATE_IN_PROGRESS":
        set_progress(f'status of {stack_name}: "{stack["StackStatus"]}"')
        time.sleep(15)
        response = client.describe_stacks(StackName=stack_name)
        stack = response["Stacks"][0]

    if stack["StackStatus"] == "CREATE_COMPLETE":
        set_progress("Stack creation was successful")
        return stack
    else:
        events = client.describe_stack_events(StackName=stack_name)
        logger.debug(events)
        error_msg = ""
        i = 1
        for event in events["StackEvents"]:
            if event["ResourceStatus"] == "CREATE_FAILED":
                error_msg += f'Error {i}: {event["ResourceStatusReason"]} '
                i += 1
        raise Exception(error_msg)


def update_cb_resource(resource, stack, env, job, client, cft_prefix):
    """
    Sets metadata on the resource object in the CB DB, then create/update
    server records within that resource
    """
    logger.debug(f"Stack info: {stack}")
    # Write outputs to Resource
    write_outputs_to_resource(resource, stack, cft_prefix)
    write_stack_id_to_resource(resource, stack)
    # Associate Servers (EC2 Instances) with Resource
    create_or_update_cb_servers(resource, env, job, client)


def write_stack_id_to_resource(resource, stack):
    stack_id = stack["StackId"]
    field_name = "cft_stack_id"
    create_cf(field_name, "CloudFormation Stack ID",
              "ID of the provisioned CloudFormation Stack",
              show_on_servers=True, show_as_attribute=True)
    resource.set_value_for_custom_field(field_name, stack_id)


def write_outputs_to_resource(resource, stack, cft_prefix):
    """
    Write the outputs of the executed CFT back to the Resource as Parameters
    """
    try:
        outputs = stack["Outputs"]
    except KeyError:
        logger.debug("No outputs defined for CFT, skipping outputs.")
        return
    for output in outputs:
        try:
            description = output["Description"]
        except KeyError:
            description = "Used by the CloudFormation Template blueprint"

        label = output["OutputKey"]
        field_name = f"{cft_prefix}output_{label}"
        value = output["OutputValue"]
        logger.debug(f"Writing output to Resource. Label: {label}, value: " f"{value}")
        create_field_set_value(field_name, label, value, description, resource)


def create_or_update_cb_servers(resource, env, job, client):
    cft_resources = client.describe_stack_resources(StackName=resource.cft_stack_name)
    group = resource.group
    rh = env.resource_handler.cast()
    for cft_resource in cft_resources["StackResources"]:
        if cft_resource["ResourceType"] == "AWS::EC2::Instance":
            svr_id = cft_resource["PhysicalResourceId"]
            if svr_id:
                ec2_client = rh.get_boto3_client(
                    region_name=env.aws_region, service_name="ec2"
                )
                ec2_data = ec2_client.describe_instances(InstanceIds=[svr_id])[
                    "Reservations"
                ][0]["Instances"][0]
                az = ec2_data["Placement"]["AvailabilityZone"]
                region = az[:-1]
                vpc_id = ec2_data["VpcId"]
                instance_type = ec2_data["InstanceType"]
                try:
                    server = Server.objects.get_or_create(
                        resource_handler_svr_id=svr_id,
                        group=group,
                        environment=env,
                        resource_handler=rh,
                    )[0]
                    server.resource = resource
                    server.owner = resource.owner
                    server.save()

                    tech_dict = {
                        "ec2_region": region,
                        "availability_zone": az,
                        "instance_id": svr_id,
                        "vpc_id": vpc_id,
                        "instance_type": instance_type,
                    }
                    rh.update_tech_specific_server_details(server, tech_dict)
                    try:
                        server.refresh_info()
                    except NotFoundException:
                        logger.warning(
                            f"Server object could not be created for "
                            f"instance id: svr_id, check to be sure "
                            f"that the VPC selected is available in "
                            f"CloudBolt"
                        )
                except Exception as err:
                    set_progress(
                        f"Adding a server to the resource failed. " f"error: {err}"
                    )
                    raise err

                # Add server to the job.server_set, and set creation event
                job.server_set.add(server)
                job.save()
                msg = "Server created by CloudFormation Template job"
                add_server_event("CREATION", server, msg, profile=job.owner, job=job)


def save_cft_to_resource(resource, cft):
    cf = create_cf(
        "cloud_formation_template",
        "CloudFormation Template",
        "CloudFormation Template Contents",
        cf_type="CODE",
    )
    resource.set_value_for_custom_field("cloud_formation_template", cft)


if __name__ == "__main__":
    job_id = sys.argv[1]
    j = Job.objects.get(id=job_id)
    run = run(j)
    if run[0] == "FAILURE":
        set_progress(run[1])
