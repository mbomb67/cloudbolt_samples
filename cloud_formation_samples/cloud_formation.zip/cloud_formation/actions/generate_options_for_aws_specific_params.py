"""
Handles generating options for AWS Specific Parameters in a CloudFormation template
https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/parameters-section-structure.html#aws-specific-parameter-types

Most of the data from these lookups are available in the AWS Resource Handler
"""

from infrastructure.models import CustomField, Environment
from orders.models import CustomFieldValue


def get_az_options(env_id):
    try:
        environment = Environment.objects.get(id=env_id)
        zone_field = environment.custom_fields.get(name="aws_availability_zone")
        opts = CustomFieldValue.objects.filter(field=zone_field)
        return [opt.value for opt in opts]
    except:
        return []


def get_options_list(field, control_value=None, **kwargs):
    options = []
    field_data = field.name.split("_")
    aws_param_service = field_data[-3]
    aws_param_ns = field_data[-2]
    aws_param_name = field_data[-1]

    if control_value:
        if aws_param_service == "EC2":
            if aws_param_ns == "AvailabilityZone":
                options = get_az_options(control_value)

    # TODO add handling for other AWS Param types

    return options
