from django.test import TestCase


class TestGitLabConnector(TestCase):
    pass
