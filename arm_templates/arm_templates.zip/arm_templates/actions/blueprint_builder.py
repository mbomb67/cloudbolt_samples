"""
A Blueprint that automates the creation of a CloudBolt Blueprint that submits
a request for an ARM Template.

1. Allows you to upload an ARM template which will be stored on the CloudBolt
appliance.
2. Create a Blueprint that leverages that ARM template to create Azure
Resources
"""
if __name__ == "__main__":
    import os
    import sys
    import django

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
    sys.path.append("/opt/cloudbolt")
    sys.path.append("/var/opt/cloudbolt/proserv")
    django.setup()

from servicecatalog.models import ServiceBlueprint
from common.methods import set_progress
from jobs.models import Job
from utilities.logger import ThreadLogger
from xui.arm_templates.shared import (
    generate_options_for_connection_info,
    generate_options_for_allowed_environments,
    create_resource_type,
    get_arm_from_source,
    add_blueprint_label,
    create_blueprint_level_params,
    add_bp_items,
    create_params,
)

logger = ThreadLogger(__name__)

BLUEPRINT_NAME = "{{blueprint_name}}"
CONNECTION_INFO_ID = "{{connection_info}}"  # ID of the connection Info for Git or AzureDevOps connection these must be labeled either github or azuredevops
ARM_URL = "{{arm_url}}"  # URL to raw git file or s3 object
ALLOWED_ENVIRONMENTS = {{allowed_environments}}  # Must be multi-select string


def run(job, **kwargs):
    set_progress(f"BLUEPRINT_NAME: {BLUEPRINT_NAME}")
    template_json = get_arm_from_source(CONNECTION_INFO_ID, ARM_URL)
    resource_type = create_resource_type(
        "arm_deployment", icon="fab fa-microsoft", label="ARM Deployment"
    )
    blueprint = ServiceBlueprint.objects.create(
        name=BLUEPRINT_NAME, resource_type=resource_type
    )
    bp_id = blueprint.id
    set_progress(f"Created Blueprint: {BLUEPRINT_NAME}, ID {bp_id}")
    set_progress(f"CONNECTION_INFO_ID: {CONNECTION_INFO_ID}")
    create_blueprint_level_params(
        blueprint, template_json, ARM_URL, ALLOWED_ENVIRONMENTS, CONNECTION_INFO_ID
    )
    add_blueprint_label(blueprint)
    add_bp_items(blueprint)

    create_params(blueprint, template_json)
    return "SUCCESS", "", ""


if __name__ == "__main__":
    job_id = sys.argv[1]
    j = Job.objects.get(id=job_id)
    run = run(j)
    if run[0] == "FAILURE":
        set_progress(run[1])
