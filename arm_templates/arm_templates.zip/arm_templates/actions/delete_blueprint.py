"""
Delete an ARM Template backed Blueprint and all of it's dependencies:
- ServiceBlueprint
- CustomField
- Generate Options Actions associated with the Blueprint
- FieldDependency
"""

from common.methods import set_progress
from resourcehandlers.aws.models import AWSHandler
from servicecatalog.models import ServiceBlueprint

BLUEPRINT_ID = "{{blueprint_id}}"


def get_custom_fields(bp):
    bp_param_prefix = f"cft_{bp.id}_"
    cfs = bp.custom_fields_for_resource.filter(name__startswith=bp_param_prefix)
    return cfs


def run(**kwargs):
    bp = ServiceBlueprint.objects.get(id=BLUEPRINT_ID)
    # Get BP Specific Params
    custom_fields = get_custom_fields(bp)
    # Get FieldDependencies field_dependency_controlling_set, field_dependency_dependent_set

    # Delete FieldDependencies

    # Delete Parameters

    # Delete BP
