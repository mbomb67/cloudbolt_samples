"""
Methods for the ARM Template XUI that need to be used in different actions
are stored in this module.
"""
import json
import requests
import urllib

from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Q

from behavior_mapping.models import SequencedItem
from cbhooks.models import CloudBoltHook, HookPoint, HookPointAction, OrchestrationHook
from common.methods import set_progress
from infrastructure.models import (
    Environment,
    CustomField,
    FieldDependency,
    Server,
    Namespace,
)
from orders.models import CustomFieldValue
from resources.models import ResourceType
from servicecatalog.models import RunCloudBoltHookServiceItem, TearDownServiceItem
from tags.models import CloudBoltTag
from utilities.events import add_server_event
from utilities.exceptions import CloudBoltException
from utilities.logger import ThreadLogger
from utilities.models import ConnectionInfo

logger = ThreadLogger(__name__)


def get_conn_info_type(conn_info):
    try:
        conn_info.labels.get(name="github")
        conn_info_type = "github"
    except ObjectDoesNotExist:
        try:
            conn_info.labels.get(name="gitlab")
            conn_info_type = "gitlab"
        except ObjectDoesNotExist:
            raise CloudBoltException(
                f"Github or Gitlab label not found on {conn_info} Connection."
            )
    logger.debug(
        f"Connection info: {conn_info.name} determined to be type of "
        f"{conn_info_type}"
    )
    return conn_info_type


def generate_options_for_resource_type():
    rts = ResourceType.objects.all()
    options = [(rt.id, rt.label) for rt in rts]

    return options


def generate_options_for_connection_info(server=None, **kwargs):
    cis = ConnectionInfo.objects.filter(
        Q(labels__name="github")
        | Q(labels__name="gitlab")
    )

    options = [(0, "Public Repository")]

    for ci in cis:
        if ci.name == "CloudBolt Content Library":
            continue
        ci_type = get_conn_info_type(ci)
        options.append((ci.id, f"{ci.name}: {ci_type}"))
    return options


def generate_options_for_allowed_environments(server=None, **kwargs):
    envs = Environment.objects.filter(
        resource_handler__resource_technology__modulename__contains="azure_arm"
    )

    return envs


def create_param_name(param_prefix, bp_id):
    return f"{param_prefix}_{bp_id}"


def create_custom_field_option(blueprint, value, field, cf_type):
    """
    Create a CustomFieldValue for a Custom Field, then add that value to the
    Blueprint level Parameter. This will check first to see if the value
    already exists for that parameter on the blueprint, and if so, not re-add
    to the Blueprint
    """
    logger.debug(
        f"Creating Parameter: {field.name} option, type: {cf_type}," f" Value: {value}"
    )
    if cf_type == "STR":
        cfv = CustomFieldValue.objects.get_or_create(str_value=value,
                                                     field=field)[0]
    elif cf_type == "INT":
        cfv = CustomFieldValue.objects.get_or_create(int_value=value,
                                                     field=field)[0]
    elif cf_type == "BOOL":
        cfv = CustomFieldValue.objects.get_or_create(boolean_value=value,
                                                     field=field)[0]
    elif cf_type == "CODE":
        cfv = CustomFieldValue.objects.get_or_create(txt_value=value,
                                                     field=field)[0]
    else:
        logger.warn(
            f"Unknown Parameter type: {cf_type}, passed in, not "
            f"creating custom field option for field: {field}"
        )
        return None
    cfvs = blueprint.get_cfvs_for_custom_field(field.name)
    if cfv not in cfvs:
        # Don't want to re-add a value if it already exists on the BP
        blueprint.custom_field_options.add(cfv.id)
    return cfv


def add_cfvs_for_field(blueprint, cf, cf_type, new_values: list):
    """
    Add new values to the blueprint for a field, remove CFVs that are not in
    new_values
    """
    existing_cfvs = blueprint.custom_field_options.filter(field__id=cf.id)
    new_cfvs = []
    for value in new_values:
        cfv = create_custom_field_option(blueprint, value, cf, cf_type)
        if cfv:
            new_cfvs.append(cfv)
    remove_old_cfvs(blueprint, existing_cfvs, new_cfvs)


def remove_old_cfvs(blueprint, existing_cfvs, new_cfvs):
    for cfv in existing_cfvs:
        if cfv not in new_cfvs:
            logger.debug(f'Removing CustomFieldValue: {cfv} from options')
            blueprint.custom_field_options.remove(cfv)


def create_cf(
    cf_name,
    cf_label,
    description,
    cf_type="STR",
    allow_multiple=False,
    required=True,
    **kwargs,
):
    namespace, _ = Namespace.objects.get_or_create(name="azure_arm_templates")

    # You can pass in show_on_servers, show_as_attribute as kwargs
    defaults = {
        "label": cf_label,
        "description": description,
        "required": required,
        "allow_multiple": allow_multiple,
        "namespace": namespace,
    }
    for key, value in kwargs.items():
        defaults[key] = value

    cf = CustomField.objects.get_or_create(
        name=cf_name, type=cf_type, defaults=defaults
    )
    return cf


def create_cloudbolt_hook(new_action_name, source_file):
    # TODO: Need to figure out how to include build and teardown in builder
    root_dir = "/var/opt/cloudbolt/proserv/xui/arm_templates/actions/"
    hook, hook_created = CloudBoltHook.objects.get_or_create(
        name=new_action_name, source_code_url=f"file://{root_dir}{source_file}"
    )
    hook.get_runtime_module()
    hook.description = "Used for ARM Template Builder"
    hook.shared = True
    hook.save()
    if hook_created:
        set_progress(f"CloudBolt Hook created: {new_action_name}")
    else:
        set_progress(f"CloudBolt Hook retrieved: {new_action_name}")
    return hook


def create_generated_options_action(new_action_name, source_file):
    # Create Action (CloudBoltHook)
    hook = create_cloudbolt_hook(new_action_name, source_file)

    # Create HookPointAction
    hp_id = HookPoint.objects.get(name="generated_custom_field_options").id
    hpa = HookPointAction.objects.get_or_create(
        name=new_action_name, hook=hook, hook_point_id=hp_id
    )[0]
    hpa.enabled = True
    hpa.continue_on_failure = False
    hpa.save()

    oh = OrchestrationHook.objects.get_or_create(
        name=new_action_name, cloudbolthook=hook
    )[0]
    oh.hookpointaction_set.add(hpa)
    oh.save()

    return oh


def create_param_label(param):
    # RobF this likely needs to change, depending on the format of CFT params
    param_label = " ".join(camel_case_split(param)).title()
    # Handles QuickStart templates where underscores are used
    param_label = param_label.replace("_", " ")
    return param_label


def camel_case_split(string):
    words = [[string[0]]]
    for c in string[1:]:
        if words[-1][-1].islower() and c.isupper():
            words.append(list(c))
        else:
            words[-1].append(c)
    return ["".join(word) for word in words]


def get_arm_from_source(connection_info_id, url):
    if int(connection_info_id) != 0:
        conn_info = ConnectionInfo.objects.get(id=connection_info_id)
        conn_info_type = get_conn_info_type(conn_info)
    else:
        conn_info_type = 'public'

    if conn_info_type == "github":
        arm_template = get_template_from_github(conn_info, url)
    elif conn_info_type == "gitlab":
        arm_template = get_template_from_gitlab(conn_info, url)
    elif conn_info_type == 'public':
        arm_template = get_public_template(url)
    else:
        raise Exception(f"Connection Info type not recognized: " f"{conn_info_type}")
    return arm_template


def get_public_template(url):
    if url.find('raw') == -1:
        raise CloudBoltException(f'URL entered was not in raw format, please '
                                 f're-submit request using a raw formatted '
                                 f'URL')
    response = requests.get(url)
    response.raise_for_status()
    return response.content.decode("utf-8")


def get_template_from_gitlab(conn_info, url):
    # For gitlab, it doesn't matter if the URL passed is the Raw or the normal
    # URL. The URL needs to be reconstructed to make an API call. The token
    # created for auth will need at a minimum read_api and read_repository
    base_url = f"https://{url.split('/')[2]}:443/api/v4"
    project_path = "/".join(url.split("/-/")[0].split("/")[-2:])
    project_id = urllib.parse.quote(project_path, safe="")
    url_split = url.split("/-/")[1].split("/")
    branch = url_split[1]
    file_path = urllib.parse.quote("/".join(url_split[2:]), safe="")
    path = f"/projects/{project_id}/repository/files/{file_path}/raw" f"?ref={branch}"
    set_progress(f"Submitting request to GitLab URL: {path}")
    headers = {
        "PRIVATE-TOKEN": conn_info.password,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    request_url = f"{base_url}{path}"
    r = requests.get(request_url, auth=None, headers=headers)
    r.raise_for_status()
    r_json = r.json()
    raw_file_json = json.dumps(r_json)
    return raw_file_json


def get_template_from_github(conn_info, cft_url):
    # Will read a github
    import base64

    url_split = cft_url.split("/")
    username = url_split[3]
    repo = url_split[4]
    if cft_url.startswith("https://github.com"):
        branch = url_split[6]
    else:
        branch = url_split[5]
    file_path = cft_url.split(f"/{branch}/")[1].split("?")[0]

    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"token {conn_info.password}",
    }
    git_url = (
        f"https://api.github.com/repos/{username}/{repo}/contents/"
        f"{file_path}?ref={branch}"
    )
    response = requests.get(git_url, headers=headers)
    response.raise_for_status()
    data = response.json()
    content = data["content"]
    file_content_encoding = data.get("encoding")
    if file_content_encoding == "base64":
        content = base64.b64decode(content).decode()
    return content


def add_blueprint_label(blueprint):
    # Create Label if it doesn't exist
    label = CloudBoltTag.objects.get_or_create(
        name="ARM Template", model_name="serviceblueprint"
    )[0]
    # Add Label to Blueprint
    blueprint.tags.add(label)
    return None


def create_cf_bp_options(
    cf_name,
    cf_label,
    description,
    blueprint,
    values: list,
    cf_type="STR",
    allow_multiple=False,
    required=True,
    **kwargs,
):
    # Create the Custom Field
    cf = create_cf(
        cf_name, cf_label, description, cf_type, allow_multiple, required, **kwargs
    )[0]

    # Add it to the Blueprint
    blueprint.custom_fields_for_resource.add(cf)

    add_cfvs_for_field(blueprint, cf, cf_type, values)

    return cf


def create_blueprint_level_params(
    blueprint, template_json, arm_url, allowed_environments, conn_info_id
):
    set_progress(f"conn_info_id: {conn_info_id}")
    # Save Cloud Formation Template
    create_cf_bp_options(
        "arm_template",
        "ARM Template",
        "ARM Template Contents",
        blueprint,
        [template_json],
        cf_type="CODE",
    )

    # Save Allowed Environments
    env_ids = ",".join(allowed_environments)
    allowed_envs_cf = create_cf_bp_options(
        "arm_allowed_env_ids",
        "Allowed Environments",
        "A list of the IDs of Environments " "allowed for the ARM Template",
        blueprint,
        [env_ids],
    )

    # Save ARM URL
    create_cf_bp_options(
        "arm_url",
        "ARM Template URL",
        "The URL where the ARM Template is located in Source" " Control",
        blueprint,
        [arm_url],
    )

    # Save Connection Info ID
    create_cf_bp_options(
        "arm_conn_info_id",
        "ConnectionInfo ID",
        "The ID of the Connection Info for Source Control",
        blueprint,
        [conn_info_id],
    )

    # Create Environment Parameter, add to Blueprint
    env_cf = create_cf_bp_options(
        "arm_env_id", "Environment", "Azure Environment", blueprint, []
    )
    SequencedItem.objects.get_or_create(custom_field=env_cf)

    # Create Resource Group Parameter, add to Blueprint
    rg_cf, cf_created = create_cf(
        "arm_resource_group",
        "Resource Group",
        "Azure Resource Group",
        show_on_servers=True,
        show_as_attribute=True,
    )
    # Create Programmatically Gen Options action for Resource group
    oh = create_generated_options_action(
        "Generate options for 'arm_resource_group'",
        "generate_options_for_resource_group.py",
    )
    rg_cf.orchestration_hooks.add(oh)
    rg_cf.save()
    blueprint.custom_fields_for_resource.add(rg_cf)

    # Create field dependency for Resource Group
    create_field_dependency(env_cf, rg_cf)

    SequencedItem.objects.get_or_create(custom_field=rg_cf)

    # Create ARM Deployment Name param
    cf = create_cf_bp_options(
        "arm_deployment_name",
        "ARM Deployment Name",
        "Name of the deployment in Azure",
        blueprint,
        [],
        show_on_servers=True,
    )
    SequencedItem.objects.get_or_create(custom_field=cf)

    # Create Programmatically Gen Options action for environment
    oh = create_generated_options_action(
        "Generate options for 'arm_env_id'", "generate_options_for_env_id.py"
    )
    env_cf.orchestration_hooks.add(oh)
    env_cf.save()
    blueprint.custom_fields_for_resource.add(env_cf)

    # Create Field Dependency for Environment to read from list of allowed envs
    create_field_dependency(allowed_envs_cf, env_cf)


def create_field_dependency(
    control_field, dependent_field, dependency_type: str = "REGENOPTIONS"
):
    dependency, _ = FieldDependency.objects.get_or_create(
        controlling_field=control_field,
        dependent_field=dependent_field,
        dependency_type=dependency_type,
    )
    return dependency


def add_bp_items(blueprint):
    # Add Build Item
    hook = create_cloudbolt_hook("ARM Template Build", "deploy_arm_template.py")
    oh, _ = OrchestrationHook.objects.get_or_create(
        name="ARM Template Build", cloudbolthook=hook
    )
    rcbhsi, _ = RunCloudBoltHookServiceItem.objects.get_or_create(
        name="ARM Template Build",
        hook=oh,
        blueprint=blueprint,
        show_on_order_form=False,
        run_on_scale_up=False,
    )

    # Add Teardown Item
    hook = create_cloudbolt_hook("ARM Template Teardown", "teardown_arm_template.py")
    oh, _ = OrchestrationHook.objects.get_or_create(
        name="ARM Template Teardown", cloudbolthook=hook
    )
    tdsi, _ = TearDownServiceItem.objects.get_or_create(
        name="ARM Template Teardown", hook=oh, blueprint=blueprint, deploy_seq=-1
    )


def create_params(blueprint, template_json):
    bp_id = blueprint.id
    template_content = json.loads(template_json)

    template_params = template_content["parameters"]
    if template_params:
        param_prefix = f"arm_{bp_id}_"
        for key in template_params.keys():
            create_param(key, template_params, param_prefix, blueprint)


def create_param(key, template_params, param_prefix, blueprint):
    param = template_params[key]
    param_type = param["type"]
    new_param_name = f"{param_prefix}{key}"
    param_label = create_param_label(key)
    description = param.get("metadata", {}).get(
        "description", "ARM Template Builder Param"
    )
    # TODO handle constraints/regex/etc

    allow_multiple = False
    required = True
    # Forcing to lower because of ARM Template case insensitivity
    if param_type.lower() == "securestring":
        cf_type = "PWD"
    elif param_type.lower() == "string":
        cf_type = "STR"
    elif param_type.lower() == "int":
        cf_type = "INT"
    elif param_type.lower() == "bool":
        cf_type = "BOOL"
    elif param_type.lower() == "object":
        cf_type = "CODE"

    else:
        logger.warn(
            f"Unable to find a known type for parameter: {key}."
            f"This parameter will not be considered in the created"
            f"blueprint"
        )
        return

    # Create the parameter
    logger.debug(
        f"Creating Parameter: {new_param_name}, type: {type}, " f"label: {param_label}"
    )
    cf, cf_created = create_cf(
        new_param_name,
        param_label,
        description,
        cf_type,
        allow_multiple,
        required,
        show_on_servers=True,
    )

    # Add it to the Blueprint
    blueprint.custom_fields_for_resource.add(cf)

    # Do not want to set a value for passwords, just exit
    if cf_type == "PWD":
        return

    # Create Add value from parameters file as selection in dropdown
    # If a list of allowed values exists, then we want to create a dropdown
    # with those values. If allowed values are not set, check the params
    # file for a value and then the template itself for a default value
    # to set a single value for the parameter options
    allowed_values = param.get("allowedValues", None)
    if allowed_values:
        add_cfvs_for_field(blueprint, cf, cf_type, allowed_values)
    else:
        default_value = template_params[key].get("defaultValue", None)
        if default_value:
            add_cfvs_for_field(blueprint, cf, cf_type, [default_value])


def create_resource_type(type_name, **kwargs):
    defaults = {}
    for key, value in kwargs.items():
        defaults[key] = value
    resource_type, _ = ResourceType.objects.get_or_create(
        name=type_name, defaults=defaults
    )
    return resource_type


def get_or_create_cfs():
    create_cf(
        "arm_deployment_id",
        "ARM Deployment ID",
        "Used by the ARM Template blueprint",
        show_on_servers=True,
    )


def get_location_from_environment(env):
    return env.node_location


def get_provider_type_from_id(resource_id):
    return resource_id.split("/")[6]


def get_resource_type_from_id(resource_id):
    return resource_id.split("/")[7]


def get_api_version_key_from_id(id_value):
    provider_type = get_provider_type_from_id(id_value)
    resource_type = get_resource_type_from_id(id_value)
    ms_type = f"{provider_type}/{resource_type}"
    id_split = id_value.split("/")
    if len(id_split) == 11:
        ms_type = f"{ms_type}/{id_split[9]}"
    ms_type_us = ms_type.replace(".", "").replace("/", "_").lower()
    api_version_key = f"{ms_type_us}_api_version"
    return api_version_key


def get_azure_server_name(id_value):
    return id_value.split("/")[8]


def create_field_set_value(field_name_id, id_value, i, resource):
    create_cf(
        field_name_id,
        f"ARM Created Resource {i} ID",
        "Used by the ARM Template blueprint",
        show_on_servers=True,
    )
    resource.set_value_for_custom_field(field_name_id, id_value)
    return resource


def get_arm_template_for_resource(resource):
    try:
        # First try to get the latest version from source, then try stored
        arm_url = resource.get_cfv_for_custom_field("arm_url").value
        conn_info_id = resource.get_cfv_for_custom_field("arm_conn_info_id").value
        arm_template = get_arm_from_source(conn_info_id, arm_url)
    except:
        arm_template = resource.get_cfv_for_custom_field("arm_template").value
    return arm_template


def get_arm_deploy_params(resource, env):
    # Override params set in the params file by params included set on the
    # Resource
    cfvs = resource.get_cf_values_as_dict()
    bp_id = resource.blueprint_id
    arm_prefix = f"arm_{bp_id}_"
    parameters = {}
    for key in cfvs.keys():
        if key.find(arm_prefix) == 0:
            param_key = key.replace(arm_prefix, "")
            value = cfvs[key]
            if value == "[resourceGroup().location]":
                value = get_location_from_environment(env)
            parameters[param_key] = value
            cf = CustomField.objects.get(name=key)
            if cf.type == "PWD":
                logger.debug(f"Setting password: {param_key} to: ******")
            else:
                logger.debug(f"Setting param: {param_key} to: {value}")
    return parameters


def write_api_versions_to_resource(resource, template):
    # Write the API Versions back to the Resource - to be used on delete
    for template_resource in template["resources"]:
        api_version = template_resource["apiVersion"]
        ms_type = template_resource["type"]
        type_split = ms_type.split("/")
        ms_type_us = ms_type.replace(".", "").replace("/", "_").lower()
        api_version_key = f"{ms_type_us}_api_version"
        # If the API version is already set for an Azure type on the
        # resource, no need to set again, check to see if it exists then
        # set if not present
        try:
            val = resource.get_cfv_for_custom_field(api_version_key).value
            logger.debug(
                f"Value already set for api_version_key: "
                f"{api_version_key}, value: {val}"
            )
        except AttributeError:
            api_key_name = f"{type_split[-1]} API Version"
            logger.debug(f"Creating CF: {api_version_key}")
            create_cf(
                api_version_key,
                api_key_name,
                (
                    f"The API Version that {ms_type} "
                    f"resources were provisioned with in this deployment"
                ),
            )
            resource.set_value_for_custom_field(api_version_key, api_version)
        except NameError:
            resource.set_value_for_custom_field(api_version_key, api_version)
    return resource


def submit_arm_template_request(
    deployment_name, resource_group, template, parameters, wrapper, timeout=None
):
    # Submit the template request
    if timeout:
        timeout = int(timeout)
    else:
        timeout = 3600
    logger.debug(
        f"Submitting request for ARM template. deployment_name: "
        f"{deployment_name}, resource_group: {resource_group}, "
        f"template: {template}"
    )
    set_progress(
        f"Submitting ARM request to Azure. This can take a while."
        f" Timeout is set to: {timeout}"
    )
    deployment = wrapper.deploy_template(
        deployment_name, resource_group, template, parameters, timeout=timeout
    )
    set_progress(f"Deployment created successfully")
    logger.debug(f"deployment info: {deployment}")
    return deployment


def create_deployment_params(
    resource, deployment, rh, env, resource_group, wrapper, group, job
):
    deploy_props = deployment.properties
    logger.debug(f"deployment properties: {deploy_props}")
    resource.azure_region = env.node_location
    resource.arm_deployment_id = deployment.id
    resource.resource_group = resource_group
    i = 0
    for output_resource in deploy_props.additional_properties["outputResources"]:
        id_value = output_resource["id"]
        type_value = id_value.split("/")[-2]

        # If a server, create the CloudBolt Server object
        if type_value == "virtualMachines":
            resource_client = wrapper.resource_client
            api_version_key = get_api_version_key_from_id(id_value)
            api_version = resource.get_cfv_for_custom_field(api_version_key).value
            vm = resource_client.resources.get_by_id(id_value, api_version)
            vm_dict = vm.__dict__
            svr_id = vm_dict["properties"]["vmId"]
            location = vm_dict["location"]
            node_size = vm_dict["properties"]["hardwareProfile"]["vmSize"]
            disk_ids = [
                vm_dict["properties"]["storageProfile"]["osDisk"]["managedDisk"]["id"]
            ]
            for disk in vm_dict["properties"]["storageProfile"]["dataDisks"]:
                disk_ids.append(disk["managedDisk"]["id"])
            if svr_id:
                # Server manager does not have the create_or_update method,
                # so we do this manually.
                try:
                    server = Server.objects.get(resource_handler_svr_id=svr_id)
                    server.resource = resource
                    server.group = group
                    server.owner = resource.owner
                    server.environment = env
                    server.save()
                    logger.info(f"Found existing server record: '{server}'")
                except Server.DoesNotExist:
                    logger.info(
                        f"Creating new server with resource_handler_svr_id "
                        f"'{svr_id}', resource '{resource}', group '{group}', "
                        f"owner '{resource.owner}', and "
                        f"environment '{env}'"
                    )
                    server_name = get_azure_server_name(id_value)
                    server = Server(
                        hostname=server_name,
                        resource_handler_svr_id=svr_id,
                        resource=resource,
                        group=group,
                        owner=resource.owner,
                        environment=env,
                        resource_handler=rh,
                    )
                    server.save()
                    server.resource_group = resource_group
                    server.save()

                    tech_dict = {
                        "location": location,
                        "resource_group": resource_group,
                        "storage_account": None,
                        "extensions": [],
                        "availability_set": None,
                        "node_size": node_size,
                    }
                    rh.update_tech_specific_server_details(server, tech_dict, None)
                    server.refresh_info()
                # Add server to the job.server_set, and set creation event
                job.server_set.add(server)
                job.save()
                msg = "Server created by ARM Template job"
                add_server_event("CREATION", server, msg, profile=job.owner, job=job)
                api_version_key = get_api_version_key_from_id(disk_ids[0])
                api_key_name = f"{api_version_key.split('_')[1]} API Version"
                create_cf(
                    api_version_key,
                    api_key_name,
                    (
                        f"The API Version that Microsoft.Compute/disks "
                        f"resources were provisioned with in this deployment"
                    ),
                )
                # Write the api_version for Virtual Machine to the disk
                # value
                resource.set_value_for_custom_field(api_version_key, "2021-04-01")
                for disk_id in disk_ids:
                    field_name_id = f"output_resource_{i}_id"
                    resource = create_field_set_value(
                        field_name_id, disk_id, i, resource
                    )
                    i += 1
                    resource.save()
        field_name_id = f"output_resource_{i}_id"
        resource = create_field_set_value(field_name_id, id_value, i, resource)

        i += 1
        resource.save()


def get_api_version(resource_dict, id_value):
    if id_value.find("Microsoft.Resources/deployments") > -1:
        api_version = "2021-04-01"
    else:
        api_version_key = get_api_version_key_from_id(id_value)
        api_version = resource_dict[api_version_key]
    return api_version
