# explicit list of extensions to be included instead of
# the default of .py and .html only
ALLOWED_XUI_EXTENSIONS = [".py", ".html", ".png"]