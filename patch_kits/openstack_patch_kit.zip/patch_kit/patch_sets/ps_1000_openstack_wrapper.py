from utilities.logger import ThreadLogger

logger = ThreadLogger(__name__)


def patch_technology_wrapper_for_openstack():
    """
    Update OpenStack Wrapper to take in the domain name in the format of
    domain_name:domain_id to prevent issues with the list domains command
    in certain scenarios
    """
    import logging
    from resourcehandlers.openstack.openstack_wrapper import TechnologyWrapper
    import libcloud.security
    from libcloud.compute.providers import get_driver
    from django.conf import settings
    from keystoneauth1.identity import v3
    from keystoneauth1 import session, exceptions
    from openstack import connection
    from libcloud.compute.types import Provider

    def _new_initialize_driver(
        self,
        ip,
        port,
        username,
        password,
        ssl_verification=False,
        protocol="http",
        **kwargs,
    ):
        """
        Overrides the parent LibcloudTechnologyWrapper method to return an
        OpenStack specific driver.

        Also initializes a keystone connection that is required to list projects/tenants.
        """
        self.ssl_verification = ssl_verification
        auth_url = "{}://{}:{}".format(protocol, ip, port)
        tenant = kwargs.pop("location_name", None)
        domain_id = kwargs.pop("domain", None)
        # Check to see if the id is input in the format of domain_name:domain_id
        if len(domain_id.split(':')) == 2:
            self.domain = domain_id.split(':')[0]
            self.domain_id = domain_id.split(':')[1]
        else:
            self.domain = domain_id
            self.domain_id = None
        driver_kwargs = dict(
            ex_force_auth_url=auth_url,
            ex_force_auth_version="2.0_password",
            ex_tenant_name=tenant,
            proxy_url=kwargs.pop("proxy_url", None),
        )

        """
        The ssl_verification kwarg should be passable to Libcloud drivers, which should
        then pass it on to the requests lib. However, those classes don't seem to accept
        a CA Certs path. Libcloud wraps requests, but doesn't pass kwargs, it looks up
        properties like CA_CERTS_PATH set on itself.
        Instead, we will set SSL Verification flags on the global libcloud instance.
        """
        if ssl_verification:
            libcloud.security.CA_CERTS_PATH = [ssl_verification]
        else:
            libcloud.security.VERIFY_SSL_CERT = False

        cls = get_driver(Provider.OPENSTACK)
        driver = cls(username, password, **driver_kwargs)

        from novaclient.client import Client as N
        from cinderclient.client import Client as C

        # This suppresses any DEBUG level logging messages that happen in the
        # keystoneclient.sessions module. We do this because the debug logging
        # messages in this module include the user's openstack account password and Auth
        # token. Not setting this log level is a huge security risk.
        key_logger = logging.getLogger("keystoneclient.session")
        if not settings.DEBUG:
            key_logger.setLevel(logging.INFO)
            # this iso8601 module just logs info about the date and time, so
            # we'll suppress it too
            logging.getLogger("iso8601.iso8601").setLevel(logging.INFO)
        # if the logger is a job logger, make sure the logs from keystoneclient
        # go to the job log
        key_logger.addHandler(logger)

        project_id = kwargs.pop("project_id", None)
        auth_policy = kwargs.pop("auth_policy", None)
        self.identity_version = "2"
        if "A3" in auth_policy:
            auth = v3.Password(
                auth_url="{}/v3".format(auth_url),
                username=username,
                password=password,
                user_domain_name=self.domain,
                project_id=project_id,
            )
            sess = session.Session(auth=auth, verify=self.ssl_verification)
            if "I3" in auth_policy:
                from keystoneclient.v3.client import Client as K

                self.identity_version = "3"
                self.keystone = K(
                    session=sess, interface="public", project_id=project_id
                )
            else:
                auth_url = "{}/v2.0/".format(auth_url)
                from keystoneclient.v2_0.client import Client as K

                self.keystone = K(
                    username=username,
                    password=password,
                    auth_url=auth_url,
                    insecure=True,
                )

            compute_version = 2
            if "C3" in auth_policy:
                compute_version = 3
            # Use openstacksdk to make a connection to openstack RH
            # BestPractice: Default to using the openstack SDK over specific APIs like nova

            # this connection (and the tenant specific one below)
            # no longer specifies identity_interface="internal"
            # because not all openstack deployments register an "internal" endpoint for keystone
            self.connection = connection.Connection(
                session=sess, compute_api_version="2"
            )
            self.nova = N(compute_version, session=sess)
            self.cinder = C(compute_version, session=sess)

            if tenant:
                # should instantiate the nova client for the correct project instead of the default
                # project. Note that this requires a functioning keystone client, therefore this
                # cannot be combined with the code above and we indeed need to re-create the auth
                # and sess here instead

                # tenant_specific nova is used to create new servers in the correct project
                project_id = self.get_location_by_name(tenant).id
                auth = v3.Password(
                    auth_url="{}/v3".format(auth_url),
                    username=username,
                    password=password,
                    user_domain_name=self.domain,
                    project_id=project_id,
                )
                sess = session.Session(auth=auth, verify=self.ssl_verification)
                self.connection = connection.Connection(
                    session=sess, compute_api_version="2"
                )

                # Override self.nova to use the tenant-specific one by default. (This used to be tenant_specific_nova
                # but that was not being used.)
                self.nova = N(compute_version, session=sess, project_id=project_id)
                logger.info(
                    f"Connected to nova with a tenant-specific session with tenant '{tenant}'."
                )
        else:
            auth_url = "{}/v2.0/".format(auth_url)
            from keystoneclient.v2_0.client import Client as K

            self.keystone = K(
                username=username, password=password, auth_url=auth_url, insecure=True
            )

            self.nova = N(
                2,
                username=username,
                api_key=password,
                project_id=tenant,
                auth_url=auth_url,
                insecure=True,
            )
            self.cinder = C(
                2,
                username=username,
                api_key=password,
                project_id=tenant,
                auth_url=auth_url,
                insecure=True,
            )

        return driver

    def _new_get_domain_id_by_name(self, name: str) -> str:
        if self.domain_id:
            return self.domain_id
        else:
            return self.keystone.domains.find(name=name).id

    TechnologyWrapper.initialize_driver = _new_initialize_driver
    TechnologyWrapper._get_domain_id_by_name = _new_get_domain_id_by_name
