# Patch Kit
"Patch Kit" is a Django app that provides some structure for deploying dynamic runtime patches (aka Monkey Patches) for
a given CloudBolt instance.

## About Dynamic Patches
Sometimes there's just a small tweak that is needed to bring a customer/prospect CB instance in-line with requirements. Patch Kit is great at overriding the functionality of existing Funtions and Methods. It's not intended to modify or change Models and the Database.

The Dynamic Patches enabled by Patch Kit are ideal for POCs and situations where an immediate fix is needed without releasing a new updater or modifying compiled code. Ideally, the changes added via Patch Kit are rolled into the product with the next release if it's determined they're appropriate for all CloudBolt customers. 

## Installing Patch Kit
It's required that Patch Kit loads automatically when your CloudBolt instance starts. After copying (or cloning) this directory (patch_kit) to `/var/opt/cloudbolt/proserv/`, you'll add the following line to `/var/opt/cloudbolt/proserv/customer_settings.py` to ensure CloudBolt loads and starts Patch Kit

```python
from settings import INSTALLED_APPS, PROSERV_DIR
INSTALLED_APPS += ('patch_kit.apps.PatchKitConfig',)
```

After adding these lines, restart the CloudBolt instance with: `systemctl restart httpd`

## Using Patch Kit
Patches are organized into "Patch Sets" and are stored in the `patch_kit/patch_sets` sub-directory with a filename
matching `ps_*.py`. For instance, if I have a patch set for some changes for CustomerX, I could name this Patch
Set `ps_customer_x.py`, copy it to `/var/opt/cloudbolt/proserv/patch_kit/patch_set/`, and restart `httpd`.

