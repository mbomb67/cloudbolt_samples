from utilities.logger import ThreadLogger

logger = ThreadLogger(__name__)


def patch_arm_template_location():
    """
        This patch wraps the the platform-provided version of the
        "deploy_arm_template" method that, given a name of a template,
        loads the template based upon directory and file conventions.

        This patch allows the caller to override this hard-coded convention
        by specifying the full location of the json-formatted azure template
        file to load rather than relying on convention.
    :return:
    """
    import json
    from resourcehandlers.azure_arm.models import AzureARMHandler

    def new_deploy_arm_template(
            self, name, resource_group, template_path, parameters, timeout=3600
    ):
        wrapper = self.cast().get_api_wrapper()
        with open(template_path, "r") as f:
            template_string = f.read()
            template = json.loads(template_string)
        return wrapper.deploy_template(
            name, resource_group, template, parameters, timeout=timeout
        )

    AzureARMHandler.deploy_arm_template = new_deploy_arm_template
